"""Package the canonical shared customer UI; native adapters do not fork website screens."""
from pathlib import Path
import argparse,shutil,subprocess,json
parser=argparse.ArgumentParser();parser.add_argument('website');parser.add_argument('--site-version',type=int,required=True);args=parser.parse_args()
root=Path(__file__).resolve().parents[1];source=Path(args.website).resolve();stage=root/'build/web-source'
assert (source/'src/components/CustomerApp.tsx').is_file(), 'Pass the canonical StudioFlow website checkout'
assert 'CustomerBirthDateField' in (source/'src/components/AuthPage.tsx').read_text(), 'Shared registration calendar missing'
assert 'customerAvailability' in (source/'src/components/customer/BookingFlow.tsx').read_text(), 'Shared authoritative availability missing'
if stage.exists():shutil.rmtree(stage)
stage.mkdir(parents=True)
for name in ['src','public']:shutil.copytree(source/name,stage/name)
for name in ['package.json','package-lock.json','tsconfig.json']:shutil.copy2(source/name,stage/name)
(stage/'node_modules').symlink_to(source/'node_modules',target_is_directory=True)
for name in ['index.html','entry.tsx','vite.config.mjs']:shutil.copy2(root/'android-web'/name,stage/name)
shutil.copy2(root/'android-web/native-bridge.js',stage/'public/native-bridge.js');shutil.copy2(root/'android-web/native.css',stage/'src/native.css')
# Bound API latency on Android while preserving caller cancellation and normal TLS.
p=stage/'src/lib/supabase.ts';s=p.read_text();assert 'timedFetch' not in s
s=s.replace('// Publishable browser key',"const timedFetch:typeof fetch=async(input,init:RequestInit={})=>{const c=new AbortController();const relay=()=>c.abort();const timer=setTimeout(()=>c.abort(),20000);init.signal?.addEventListener('abort',relay,{once:true});if(init.signal?.aborted)c.abort();try{return await fetch(input,{...init,signal:c.signal})}finally{clearTimeout(timer);init.signal?.removeEventListener('abort',relay)}};\n// Publishable browser key").replace('auth: { persistSession:', 'global:{fetch:timedFetch},\n auth: { persistSession:');p.write_text(s)
p=stage/'src/components/customer/useCustomerCatalog.ts';s=p.read_text().replace("const {data,error}=await supabase.rpc('studioflow_customer_catalog');","const {data,error}=await supabase.rpc('studioflow_customer_catalog').then(r=>r,()=>({data:null,error:new Error('Connection unavailable')}));");p.write_text(s)
r=subprocess.run(['node',str(source/'node_modules/vite/bin/vite.js'),'build','--config','vite.config.mjs'],cwd=stage)
if r.returncode:raise SystemExit(r.returncode)
assets=root/'app/src/main/assets/web'
if assets.exists():shutil.rmtree(assets)
shutil.copytree(stage/'dist',assets)
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
(root/'docs/web-ui-source.json').write_text(json.dumps({'website_source_commit':sha,'site_version':args.site_version,'build':'android-1.2.0','implementation':'Kotlin container with packaged shared customer UI','adaptations':['native checkout/share/clipboard/export','bounded Android requests','immediate home rendering','no stale service worker'],'shared_screens':['full home and six tabs','registration/profile DD-MM-YYYY calendar','profile error isolation','authoritative availability recovery']},indent=2)+'\n')
print('Packaged canonical shared customer UI')
