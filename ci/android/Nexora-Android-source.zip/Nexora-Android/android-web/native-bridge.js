// Android WebView compatibility, with cryptographic UUIDs.
if(!String.prototype.replaceAll)Object.defineProperty(String.prototype,'replaceAll',{value:function(search,replacement){if(search instanceof RegExp){if(!search.global)throw new TypeError('Global regexp required');return this.replace(search,replacement)}return this.replace(new RegExp(String(search).replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'g'),replacement)}});
if(!Array.prototype.at)Object.defineProperty(Array.prototype,'at',{value:function(index){let i=Math.trunc(index)||0;if(i<0)i+=this.length;return this[i]}});
if(!Object.hasOwn)Object.hasOwn=(object,key)=>Object.prototype.hasOwnProperty.call(object,key);
if(!crypto.randomUUID)crypto.randomUUID=()=>{const b=crypto.getRandomValues(new Uint8Array(16));b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;const h=Array.from(b,x=>x.toString(16).padStart(2,'0')).join('');return h.slice(0,8)+'-'+h.slice(8,12)+'-'+h.slice(12,16)+'-'+h.slice(16,20)+'-'+h.slice(20)};
(() => {
 if(window.top!==window||window.__nexoraNativeBooted||!window.NexoraNative)return;
 window.__nexoraNativeBooted=true;window.__NEXORA_ANDROID__=true;
 const bridge=window.NexoraNative,waiting=new Map();let sequence=0;
 bridge.onmessage=({data})=>{
  let value;try{value=JSON.parse(data)}catch{return}
  const task=waiting.get(value.id);if(!task)return;
  if(value.event==='payment'||task.options){waiting.delete(value.id);if(value.ok)task.options.handler?.(value.response);else{task.failure?.(value.response);task.options.modal?.ondismiss?.()}return;}
  waiting.delete(value.id);clearTimeout(task.timer);value.ok?task.resolve(value.value):task.reject(new Error(value.error||'Please try again.'));
 };
 const call=(action,value={})=>new Promise((resolve,reject)=>{const id=String(++sequence);const timer=setTimeout(()=>{waiting.delete(id);reject(new Error('Android action timed out. Try again.'))},120000);waiting.set(id,{resolve,reject,timer});bridge.postMessage(JSON.stringify({id,action,...value}))});
 window.nexoraAndroid={call};
 try{Object.defineProperty(navigator,'share',{configurable:true,value:value=>call('share',{text:[value.title,value.text,value.url].filter(Boolean).join('\n')})})}catch{}
 try{Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:text=>call('copy',{text:String(text)})}})}catch{}
 window.Razorpay=class{
  constructor(options){this.options=options}
  on(name,callback){if(name==='payment.failed')this.failure=callback}
  open(){const id=String(++sequence);waiting.set(id,{options:this.options,failure:this.failure});bridge.postMessage(JSON.stringify({id,action:'payment',options:{key:this.options.key,order_id:this.options.order_id,amount:this.options.amount,currency:this.options.currency,prefill:this.options.prefill}}))}
  close(){this.options.modal?.ondismiss?.()}
 };
 const originalClick=HTMLAnchorElement.prototype.click;
 HTMLAnchorElement.prototype.click=function(){
  if(this.download&&this.href.startsWith('blob:')){
   fetch(this.href).then(r=>r.blob()).then(blob=>{if(blob.size>10*1024*1024)throw new Error('File too large');return new Promise(resolve=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.readAsDataURL(blob)}).then(base64=>call('saveFile',{name:this.download,type:blob.type,base64}))}).catch(()=>alert('File could not be saved. Please retry.'));return;
  }
  return originalClick.call(this);
 };
 let didReportReady=false;
 const ready=()=>{if(!didReportReady&&document.querySelector('.cr-app, main[role="alert"]')){didReportReady=true;requestAnimationFrame(()=>bridge.postMessage(JSON.stringify({action:'ready'})))}};
 document.addEventListener('DOMContentLoaded',()=>{ready();const observer=new MutationObserver(()=>{ready();if(didReportReady)observer.disconnect()});observer.observe(document.getElementById('root')||document.body,{childList:true,subtree:true})});
})();
