import React,{useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import type {Session} from '@supabase/supabase-js';
import {CustomerApp} from './src/components/CustomerApp';
import {AppErrorBoundary} from './src/components/AppErrorBoundary';
import {AuthPage} from './src/components/AuthPage';
import {CustomerReferralBridge} from './src/components/CustomerReferralBridge';
import {useCustomerWelcomeDelivery} from './src/components/CustomerWelcomeDelivery';
import {supabase} from './src/lib/supabase';
import './src/index.css';
import './src/native.css';
function NativeCustomerApp(){
 const [session,setSession]=useState<Session|null>(null),[authError,setAuthError]=useState('');
 const [recovery,setRecovery]=useState(()=>new URLSearchParams(location.search).has('recovery')||new URLSearchParams(location.hash.slice(1)).get('type')==='recovery');
 useCustomerWelcomeDelivery(session);
 useEffect(()=>{
  let active=true;
  const timer=setTimeout(()=>{if(active)setAuthError('Sign-in is taking longer than expected. You can still browse salons.');},12000);
  supabase.auth.getSession().then(({data,error})=>{clearTimeout(timer);if(active){setSession(data.session);setAuthError(error?'Your sign-in could not be restored. Please sign in again.':'');}}).catch(()=>{clearTimeout(timer);if(active)setAuthError('Sign-in could not be restored. Check your connection and retry.');});
  const {data}=supabase.auth.onAuthStateChange((event,next)=>{if(active){clearTimeout(timer);setSession(next);setAuthError('');if(event==='PASSWORD_RECOVERY')setRecovery(true);}});
  return()=>{active=false;clearTimeout(timer);data.subscription.unsubscribe();};
 },[]);
 return <AppErrorBoundary><CustomerReferralBridge/>{authError&&<div role="status" style={{padding:12,background:'#fff0f6',color:'#831843'}}>{authError}</div>}{recovery&&session?<AuthPage recovery customerMode/>:<CustomerApp session={session}/>}</AppErrorBoundary>;
}
createRoot(document.getElementById('root')!).render(<AppErrorBoundary><NativeCustomerApp/></AppErrorBoundary>);
