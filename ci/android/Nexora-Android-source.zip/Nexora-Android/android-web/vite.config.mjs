import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
export default defineConfig({plugins:[react(),tailwindcss()],define:{'import.meta.env.VITE_SCREEN_BUILD':JSON.stringify('android-1.2.0'),'location.origin':JSON.stringify('https://nexora-one-white-label.templateapp67.chatgpt.site')},build:{target:'chrome80',outDir:'dist',rollupOptions:{output:{inlineDynamicImports:true}}}});
