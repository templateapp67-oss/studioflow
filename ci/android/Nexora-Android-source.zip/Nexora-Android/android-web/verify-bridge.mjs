import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import {webcrypto} from 'node:crypto';
const source=readFileSync(new URL('./native-bridge.js',import.meta.url),'utf8');
function context({frame=false}={}){
 const messages=[],events={},timers=new Map();let count=0;
 const c=vm.createContext({crypto:{getRandomValues:webcrypto.getRandomValues.bind(webcrypto)},navigator:{},setTimeout:f=>{timers.set(++count,f);return count},clearTimeout:id=>timers.delete(id),requestAnimationFrame:f=>f(),MutationObserver:class{observe(){}disconnect(){}},document:{querySelector:()=>({}),getElementById:()=>({}),addEventListener:(name,fn)=>{events[name]=fn}},fetch:()=>Promise.reject(),alert:()=>{}});
 vm.runInContext("this.window=this;this.top=this;this.HTMLAnchorElement=class{click(){this.originalCalled=true}};delete String.prototype.replaceAll;delete Array.prototype.at;delete Object.hasOwn",c);
 c.NexoraNative={postMessage:value=>messages.push(JSON.parse(value))};if(frame)c.top={};
 vm.runInContext(source,c);return {c,messages,events,timers,run:s=>vm.runInContext(s,c),reply:v=>c.NexoraNative.onmessage({data:JSON.stringify(v)})};
}
test('older WebView primitives use compatible cryptographic implementations',()=>{const s=context();assert.equal(s.run("'a.b.a'.replaceAll('.','-')"),'a-b-a');assert.equal(s.run("[1,2,3].at(-1)"),3);assert.match(s.run('crypto.randomUUID()'),/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/)});
test('clipboard resolves only after Android acknowledgement',async()=>{const s=context();const p=s.c.navigator.clipboard.writeText('QA copy');assert.equal(s.messages[0].action,'copy');s.reply({id:s.messages[0].id,ok:true});await p;assert.equal(s.timers.size,0)});
test('share request contains only the selected text and URL',async()=>{const s=context();const p=s.c.navigator.share({title:'Nexora',text:'Invite',url:'https://example.test/?ref=QA'});assert.equal(s.messages[0].action,'share');assert.equal(s.messages[0].text,'Nexora\nInvite\nhttps://example.test/?ref=QA');s.reply({id:s.messages[0].id,ok:true});await p});
test('payment result is forwarded once for server verification',()=>{const s=context();let called=0;const options={key:'rzp_test_QA',order_id:'order_QA',amount:2500,handler:r=>{called++;assert.equal(r.razorpay_payment_id,'pay_QA')}};new s.c.Razorpay(options).open();const id=s.messages[0].id;s.reply({id,event:'payment',ok:true,response:{razorpay_payment_id:'pay_QA'}});s.reply({id,event:'payment',ok:true,response:{}});assert.equal(called,1)});
test('native checkout rejection and cancellation do not break the message channel',()=>{const s=context();let failed=0,closed=0;const pay=new s.c.Razorpay({modal:{ondismiss:()=>closed++}});pay.on('payment.failed',()=>failed++);pay.open();s.reply({id:s.messages[0].id,ok:false,error:'Already open'});assert.equal(failed,1);assert.equal(closed,1)});
test('readiness is emitted once and third-party frames receive no privileged adapter',()=>{const s=context();s.events.DOMContentLoaded();s.events.DOMContentLoaded();assert.equal(s.messages.filter(x=>x.action==='ready').length,1);const frame=context({frame:true});assert.equal(frame.c.nexoraAndroid,undefined);assert.equal(frame.c.NexoraNative.onmessage,undefined)});
