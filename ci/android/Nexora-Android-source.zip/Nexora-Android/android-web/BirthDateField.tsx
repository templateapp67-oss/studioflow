import React from 'react';
import {CalendarDays} from 'lucide-react';
import {customerToday} from './src/lib/customerBirthDate';
export function BirthDateField({value,onChange,required=true,className,autoComplete='bday'}:{value:string;onChange:React.ChangeEventHandler<HTMLInputElement>;required?:boolean;className?:string;autoComplete?:string;[key:string]:unknown}){
 const display=/^\d{4}-\d{2}-\d{2}$/.test(value)?value.split('-').reverse().join('-'):'DD-MM-YYYY';
 return <span className="nexora-dob"><span aria-hidden="true">{display}</span><CalendarDays size={20} aria-hidden="true"/><input aria-label="Date of Birth calendar (DD-MM-YYYY)" type="date" required={required} min="1900-01-01" max={customerToday()} value={value} onChange={onChange} autoComplete={autoComplete} className={className}/></span>;
}
