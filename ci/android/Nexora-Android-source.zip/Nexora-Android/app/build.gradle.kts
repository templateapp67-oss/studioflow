import java.util.Properties
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
val config = Properties().apply { rootProject.file("local.properties").takeIf { it.exists() }?.inputStream()?.use { load(it) } }
fun configured(name: String, default: String) = (config.getProperty(name) ?: System.getenv(name) ?: default)
fun quoted(value: String) = "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
val firebaseEnabled = file("google-services.json").exists()
if (firebaseEnabled) { apply(plugin = "com.google.gms.google-services"); apply(plugin = "com.google.firebase.crashlytics") }
android {
    namespace = "com.nexora.customer"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.nexora.customer"; minSdk = 26; targetSdk = 35; versionCode = 6; versionName = "1.2.2"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "SUPABASE_URL", quoted(configured("SUPABASE_URL", "https://zilwgiuiygqqardzutxi.supabase.co")))
        buildConfigField("String", "SUPABASE_PUBLISHABLE_KEY", quoted(configured("SUPABASE_PUBLISHABLE_KEY", "sb_publishable_Xck8H8PcTCCnEwkvBfiSLw_c973vJkH")))
        buildConfigField("String", "WEBSITE_URL", quoted("https://nexora-one-white-label.templateapp67.chatgpt.site"))
        buildConfigField("boolean", "FIREBASE_ENABLED", firebaseEnabled.toString())
    }
    buildFeatures { compose = true; buildConfig = true }
    // Keep upgrades tied to the backed-up identity. Never silently generate a new
    // machine-local debug key for a build intended to update an installed app.
    signingConfigs.getByName("debug") {
        storeFile = file(configured("NEXORA_DEBUG_KEYSTORE", "../../Nexora-Android-Signing/debug.keystore"))
        storePassword = configured("NEXORA_DEBUG_STORE_PASSWORD", "android")
        keyAlias = configured("NEXORA_DEBUG_KEY_ALIAS", "AndroidDebugKey")
        keyPassword = configured("NEXORA_DEBUG_KEY_PASSWORD", "android")
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildTypes { release { isMinifyEnabled = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.04.01"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.webkit:webkit:1.16.0")
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.test:core:1.6.1")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.0")
    implementation("androidx.navigation:navigation-compose:2.8.9")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.10.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("androidx.media3:media3-exoplayer:1.6.1")
    implementation("androidx.media3:media3-ui:1.6.1")
    implementation("com.razorpay:checkout:1.6.41")
    implementation(platform("com.google.firebase:firebase-bom:33.12.0"))
    implementation("com.google.firebase:firebase-messaging")
    implementation("com.google.firebase:firebase-analytics")
    implementation("com.google.firebase:firebase-crashlytics")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.10.1")
}

dependencyLocking { lockAllConfigurations() }
