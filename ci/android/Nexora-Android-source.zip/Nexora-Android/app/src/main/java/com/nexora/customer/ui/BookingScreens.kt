package com.nexora.customer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.nexora.customer.domain.*
import java.math.BigDecimal
import java.time.*
import kotlinx.coroutines.delay

@Composable fun BookingScreen(s: CustomerState, vm: CustomerViewModel, back: () -> Unit, summary: () -> Unit) {
    val salon = s.salons.find { it.slug == s.selection.slug } ?: return
    val selected = salon.services.filter { it.id in s.selection.serviceIds }
    LaunchedEffect(s.selection.slug, s.selection.serviceIds) { vm.loadSlots(autoNext = true) }
    val dates = remember { (0..90).map { LocalDate.now(ZoneId.of("Asia/Kolkata")).plusDays(it.toLong()) } }
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { PageTitle("Book appointment", salon.name, back) }
        item { Text("Choose a specialist", style = MaterialTheme.typography.titleMedium) }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(s.selection.stylistId == "any", { vm.editSelection { it.copy(stylistId = "any") }; vm.loadSlots() }, label = { Text("Any available") }) }
            items(salon.staff.filter { it.id in s.availability?.specialistIds.orEmpty() }) { staff -> FilterChip(s.selection.stylistId == staff.id, { vm.editSelection { it.copy(stylistId = staff.id) }; vm.loadSlots() }, label = { Text(staff.name) }) }
        } }
        item { Text("Select date & slot · IST", style = MaterialTheme.typography.titleMedium) }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(dates) { date -> FilterChip(s.selection.date == date.toString(), { vm.editSelection { it.copy(date = date.toString()) }; vm.loadSlots() }, label = { Text("${date.dayOfWeek.name.take(3)} ${date.dayOfMonth} ${date.month.name.take(3)}") }) } } }
        item { Button(onClick = { vm.loadSlots() }, enabled = !s.busy && !s.slotsLoading && selected.isNotEmpty()) { Text("Find available slots") } }
        if(s.slotsLoading) item { LinearProgressIndicator(Modifier.fillMaxWidth()); Text("Checking live salon availability…") }
        else if(s.slots.isEmpty()) item {
            Text(if(s.availability?.reason == "no_eligible_specialist") "No professional is assigned to all selected services. Change services or contact the salon." else "No bookable times on this date after working hours, advance notice and existing bookings are checked.", style = MaterialTheme.typography.bodySmall)
            s.availability?.nextDate?.let { date -> OutlinedButton(onClick = { vm.nextAvailableDate() }) { Text("Next available: $date") } }
        }
        items(s.slots.chunked(3)) { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { row.forEach { slot -> FilterChip(s.selection.slot == slot, { vm.chooseSlot(slot) }, label = { Text(slot.label) }, modifier = Modifier.weight(1f)) }; repeat(3-row.size) { Spacer(Modifier.weight(1f)) } } }
        item { Text("${selected.size} services · ${selected.sumOf { it.minutes }} minutes", style = MaterialTheme.typography.titleMedium); Text(Money.display(selected.fold(BigDecimal.ZERO) { total, item -> total + item.price })) }
        item { Button(onClick = summary, enabled = s.selection.slot != null && !s.slotsLoading && !s.busy, modifier = Modifier.fillMaxWidth()) { Text("Review booking summary") } }
    }
}
@Composable fun SummaryScreen(s: CustomerState, vm: CustomerViewModel, back: () -> Unit, ready: () -> Unit) {
    val salon = s.salons.find { it.slug == s.selection.slug } ?: return
    val selected = salon.services.filter { it.id in s.selection.serviceIds }
    val total = selected.fold(BigDecimal.ZERO) { acc, service -> acc + service.price }
    val deposit = Money.rupees(Money.depositPaise(total))
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { PageTitle("Booking summary", "Review & confirm", back) }
        item { SummaryCard("1 · SALON & VENUE", salon.name + "\n" + salon.address) }
        item { SummaryCard("2 · SELECTED SERVICES", selected.joinToString("\n") { "${it.name} · ${Money.display(it.price)}" }) }
        item { SummaryCard("3 · PROFESSIONAL", salon.staff.find { it.id == s.selection.slot?.stylistId }?.name ?: "Any available") }
        item { SummaryCard("4 · DATE & APPOINTMENT", "${s.selection.date} · ${s.selection.slot?.label.orEmpty()} IST\n${selected.sumOf { it.minutes }} minutes"); TextButton(onClick = back) { Text("Change staff, date or slot") } }
        item { Text("5 · CONTACT FOR THIS APPOINTMENT", style = MaterialTheme.typography.labelMedium); OutlinedTextField(s.selection.name, { vm.contact(it, s.selection.phone, s.selection.instructions) }, label = { Text("Full name") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(s.selection.phone, { vm.contact(s.selection.name, it, s.selection.instructions) }, label = { Text("Mobile number") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(s.selection.instructions, { vm.contact(s.selection.name, s.selection.phone, it.take(1000)) }, label = { Text("Special instructions (optional)") }, modifier = Modifier.fillMaxWidth()) }
        item { SummaryCard("6 · PAYMENT", "Total: ${Money.display(total)}\n25% advance: ${Money.display(deposit)}\nPay at salon: ${Money.display(total - deposit)}") }
        item { Text(salon.policies, style = MaterialTheme.typography.bodySmall); Text("The server checks current prices and availability before reserving. Review the reserved total before payment.", style = MaterialTheme.typography.bodySmall) }
        item { Button(onClick = { vm.reserve(ready) }, enabled = !s.busy && !s.slotsLoading && s.selection.slot != null && s.customer != null, modifier = Modifier.fillMaxWidth()) { Text(if(s.rescheduleId != null) "Confirm new appointment time" else "Reserve & pay 25% advance") } }
    }
}
@Composable fun SummaryCard(title: String, text: String) { OutlinedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary); Text(text) } } }
@Composable fun PaymentScreen(s: CustomerState, vm: CustomerViewModel, done: () -> Unit, pay: () -> Unit) {
    val booking = s.bookings.find { it.id == s.activeBooking?.id } ?: s.activeBooking
    if(booking == null) { EmptyState("Choose an appointment to pay for.", "My bookings", done); return }
    var seconds by remember(booking.id) { mutableLongStateOf(0) }
    LaunchedEffect(booking.id, booking.expires) { while(true) { seconds = booking.expires?.let { runCatching { Duration.between(Instant.now(), Instant.parse(it)).seconds.coerceAtLeast(0) }.getOrDefault(0) } ?: 0; delay(1000) } }
    LazyColumn(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item { PageTitle("Nexora payment", "25% advance confirms your appointment") }
        item { SummaryCard("BOOKING ${booking.id.take(8)}", "${booking.name}\n${booking.date} · ${booking.time} IST\nTotal ${Money.display(booking.total)}\nAdvance ${Money.display(Money.rupees(Money.depositPaise(booking.total)))}\nPaid ${Money.display(booking.paid)}") }
        item { Text(if(booking.status == "confirmed") "Booking confirmed" else if(seconds > 0) "Reserved for %02d:%02d".format(seconds/60, seconds%60) else "Reservation expired. Recheck payment before booking again.", style = MaterialTheme.typography.titleMedium) }
        if(booking.status == "pending" && seconds > 0) {
            item { Button(onClick = pay, enabled = !s.busy && s.qr == null, modifier = Modifier.fillMaxWidth()) { Text("Pay securely · UPI / card") }; OutlinedButton(onClick = { vm.qr() }, enabled = !s.busy, modifier = Modifier.fillMaxWidth()) { Text("Show Nexora payment QR") } }
        }
        s.qr?.let { qr -> item { Text("Scan with a UPI app on another device."); AsyncImage(qr.imageUrl, "Nexora provider-generated payment QR", Modifier.fillMaxWidth().height(280.dp)); Text("Amount ${Money.display(Money.rupees(qr.amount))}"); Button(onClick = { vm.reconcile(true) }, enabled = !s.busy) { Text("I have paid · verify payment") } } }
        item { OutlinedButton(onClick = { vm.reconcile(s.qr != null) }, enabled = !s.busy) { Text("Recheck payment status") }; Text("Payment is confirmed only after server verification. Late payments are flagged for a refund.", style = MaterialTheme.typography.bodySmall) }
        item { TextButton(onClick = done) { Text("Back to My Bookings") } }
    }
}
@Composable fun BookingsScreen(s: CustomerState, vm: CustomerViewModel, signIn: () -> Unit, payment: (Booking) -> Unit, rebook: (Booking) -> Unit, reschedule: (Booking) -> Unit) {
    var filter by remember { mutableStateOf("Upcoming") }; var cancelling by remember { mutableStateOf<Booking?>(null) }
    if(s.customer == null) { EmptyState("Sign in to see appointments across all your salons.", "Sign in", signIn); return }
    val filtered = s.bookings.filter { when(filter) { "Upcoming" -> it.status in listOf("pending", "confirmed"); "Completed" -> it.status == "completed"; else -> it.status == "cancelled" } }
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { PageTitle("My bookings", "Your next visit, all in one place."); TextButton(onClick = { vm.account() }) { Text("Refresh") } }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(listOf("Upcoming", "Completed", "Cancelled")) { name -> FilterChip(filter == name, { filter = name }, label = { Text(name) }) } } }
        if(filtered.isEmpty()) item { EmptyState("No ${filter.lowercase()} bookings.") }
        items(filtered, key = { it.id }) { b -> OutlinedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(s.salons.find { it.ownerId == b.ownerId }?.name ?: "Salon appointment", style = MaterialTheme.typography.titleLarge)
            Text(b.status.uppercase(), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
            Text(b.name); Text("${b.date} · ${b.time} IST · ${b.stylist}"); Text("Total ${Money.display(b.total)} · Paid ${Money.display(b.paid)}")
            if(b.status == "pending") Button(onClick = { payment(b) }, enabled = !s.busy) { Text("Pay / verify advance") }
            Row { if(b.status in listOf("pending", "confirmed")) TextButton(onClick = { cancelling = b }, enabled = !s.busy) { Text("Cancel") }; if(b.status == "confirmed") TextButton(onClick = { reschedule(b) }) { Text("Reschedule") }; TextButton(onClick = { rebook(b) }) { Text("Rebook") } }
        } } }
    }
    cancelling?.let { b -> AlertDialog(onDismissRequest = { cancelling = null }, title = { Text("Cancel this appointment?") }, text = { Text("The salon cancellation policy applies. A refund is not automatic; contact support for any paid advance.") }, confirmButton = { TextButton(onClick = { vm.cancel(b.id); cancelling = null }) { Text("Cancel appointment") } }, dismissButton = { TextButton(onClick = { cancelling = null }) { Text("Keep booking") } }) }
}
