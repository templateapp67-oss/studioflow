package com.nexora.customer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.nexora.customer.BuildConfig
import com.nexora.customer.domain.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.MediaItem
import androidx.media3.ui.PlayerView

@Composable fun SalonScreen(s: CustomerState, vm: CustomerViewModel, back: () -> Unit, book: () -> Unit) {
    val salon = s.salons.find { it.slug == s.selection.slug }
    if(salon == null) { EmptyState("Salon is unavailable or still loading.", "Back", back); return }
    var tab by remember { mutableStateOf("Services") }
    var review by remember { mutableStateOf("") }; var rating by remember { mutableIntStateOf(5) }
    var playing by remember { mutableStateOf<PromoVideo?>(null) }
    val context = LocalContext.current
    val selected = salon.services.filter { it.id in s.selection.serviceIds }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { PageTitle(salon.name, salon.city, back) }
            item { if(salon.cover.isNotBlank()) AsyncImage(salon.cover, salon.name, Modifier.fillMaxWidth().height(210.dp), contentScale = ContentScale.Crop) }
            item { Text(salon.address); Row { TextButton(onClick = { openLink(context, "https://www.google.com/maps/search/?api=1&query=" + android.net.Uri.encode(salon.address + " " + salon.city)) }) { Text("Directions") }; TextButton(onClick = { openLink(context, "tel:${salon.phone.filter { it.isDigit() || it == '+' }}") }) { Text("Call") }; TextButton(onClick = { share(context, "${salon.name}\n${BuildConfig.WEBSITE_URL}/?site=${salon.slug}") }) { Text("Share") } } }
            item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(listOf("Services", "Staff", "Packages", "Videos", "Reviews", "About")) { name -> FilterChip(tab == name, { tab = name }, label = { Text(name) }) } } }
            when(tab) {
                "Services", "Packages" -> {
                    if(tab == "Packages") item { Text("Packages & combinations", style = MaterialTheme.typography.titleMedium); Text("Choose published package services or combine services below.", style = MaterialTheme.typography.bodySmall) }
                    items(salon.services, key = { it.id }) { service ->
                        OutlinedCard(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            if(service.image.isNotBlank()) AsyncImage(service.image, null, Modifier.size(64.dp), contentScale = ContentScale.Crop)
                            Column(Modifier.weight(1f)) { Text(service.name, style = MaterialTheme.typography.titleSmall); Text(service.description, maxLines = 2, style = MaterialTheme.typography.bodySmall); Text("${Money.display(service.price)} · ${service.minutes} min", color = MaterialTheme.colorScheme.primary) }
                            Checkbox(service.id in s.selection.serviceIds, { checked -> vm.editSelection { it.copy(serviceIds = if(checked) it.serviceIds + service.id else it.serviceIds - service.id) } })
                        } }
                    }
                }
                "Staff" -> items(salon.staff, key = { it.id }) { staff -> OutlinedCard(Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) { AsyncImage(staff.avatar, staff.name, Modifier.size(64.dp), contentScale = ContentScale.Crop); Column { Text(staff.name, style = MaterialTheme.typography.titleMedium); Text(staff.role)
                    if(staff.experienceYears > 0) Text("${staff.experienceYears} years of experience")
                    if(staff.bio.isNotBlank()) Text(staff.bio, style = MaterialTheme.typography.bodySmall)
                    val expertise = salon.services.filter { it.id in staff.assigned }
                    if(expertise.isNotEmpty()) Text(expertise.joinToString { it.name }, style = MaterialTheme.typography.bodySmall)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(staff.work) { photo -> Column { AsyncImage(photo.image, photo.caption.ifBlank { "Specialist portfolio" }, Modifier.size(140.dp), contentScale = ContentScale.Crop); if(photo.caption.isNotBlank()) Text(photo.caption, style = MaterialTheme.typography.bodySmall) } } }
                    TextButton(onClick = { vm.editSelection { it.copy(stylistId = staff.id) }; book() }, enabled = selected.isNotEmpty() && !s.busy) { Text("Book with ${staff.name}") }
                } } } }
                "Videos" -> { if(salon.videos.isEmpty()) item { EmptyState("This salon has not published any promotion videos.") }; items(salon.videos) { video -> ElevatedCard(onClick = { if(video.playable.startsWith("https://")) playing = video else openLink(context, video.source) }, modifier = Modifier.fillMaxWidth()) { AsyncImage(video.thumbnail, video.title, Modifier.fillMaxWidth().height(170.dp), contentScale = ContentScale.Crop); Text("▶ ${video.title}", Modifier.padding(16.dp)) } } }
                "Reviews" -> {
                    val average = s.reviews.takeIf { it.isNotEmpty() }?.map { it.rating }?.average()
                    item { Text(average?.let { "%.1f / 5 · %d reviews".format(it, s.reviews.size) } ?: "No customer reviews yet", style = MaterialTheme.typography.titleLarge) }
                    items(s.reviews) { item -> OutlinedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("${item.name} · ${"★".repeat(item.rating.coerceIn(0,5))}"); if(item.verified) Text("Verified visit", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall); Text(item.comment); if(item.image.isNotBlank()) AsyncImage(item.image, "Customer review photograph", Modifier.fillMaxWidth().height(180.dp), contentScale = ContentScale.Crop) } } }
                    if(s.customer != null) item { Text("Review a completed visit", style = MaterialTheme.typography.titleMedium); Row { (1..5).forEach { n -> IconButton(onClick = { rating = n }) { Icon(Icons.Outlined.Star, "$n stars", tint = if(n <= rating) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant) } } }; OutlinedTextField(review, { review = it }, label = { Text("Your experience (10–2000 characters)") }, modifier = Modifier.fillMaxWidth()); Button(onClick = { vm.review(salon.slug, rating, review) }, enabled = !s.busy && review.length in 10..2000) { Text("Submit review") } }
                }
                "About" -> { item { Text(salon.about); Spacer(Modifier.height(16.dp)); Text("Salon policies", style = MaterialTheme.typography.titleMedium); Text(salon.policies.ifBlank { "Contact the salon for cancellation and refund policies." }) }; item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(salon.gallery) { url -> AsyncImage(url, "Salon gallery", Modifier.size(180.dp), contentScale = ContentScale.Crop) } } }; item { Text("More salons", style = MaterialTheme.typography.titleMedium); s.salons.filter { it.slug != salon.slug && it.city.equals(salon.city, true) }.take(4).forEach { other -> TextButton(onClick = { vm.openSalon(other.slug) }) { Text(other.name) } } } }
            }
        }
        Surface(shadowElevation = 8.dp) { Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) { Column(Modifier.weight(1f)) { Text("${selected.size} services · ${selected.sumOf { it.minutes }} min", style = MaterialTheme.typography.bodySmall); Text(Money.display(selected.fold(java.math.BigDecimal.ZERO) { total, service -> total + service.price }), style = MaterialTheme.typography.titleLarge) }; Button(onClick = book, enabled = selected.isNotEmpty() && !s.busy) { Text(if(s.customer == null) "Sign in to book" else "Book appointment") } } }
    }
    playing?.let { video -> AlertDialog(onDismissRequest = { playing = null }, confirmButton = { TextButton(onClick = { playing = null }) { Text("Close") } }, text = { NativeVideo(video.playable) }) }
}
@Composable fun NativeVideo(url: String) {
    val context = LocalContext.current
    val player = remember(url) { ExoPlayer.Builder(context).build().apply { volume = 0f; setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = false } }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(factory = { PlayerView(it).apply { this.player = player } }, modifier = Modifier.fillMaxWidth().height(220.dp))
}
