package com.nexora.customer.domain

import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** API dates stay ISO; customer-facing dates always use day-month-year. */
fun cleanDetail(value: String?): String = value?.trim()?.takeUnless { it.equals("null", true) }.orEmpty()
fun displayBirthDate(iso: String): String = runCatching {
    LocalDate.parse(cleanDetail(iso)).format(DateTimeFormatter.ofPattern("dd-MM-uuuu", Locale.ROOT))
}.getOrDefault("")
fun validBirthDate(iso: String, today: LocalDate = LocalDate.now(ZoneId.of("Asia/Kolkata"))): Boolean =
    runCatching { LocalDate.parse(iso).let { !it.isBefore(LocalDate.of(1900, 1, 1)) && !it.isAfter(today) } }.getOrDefault(false)
