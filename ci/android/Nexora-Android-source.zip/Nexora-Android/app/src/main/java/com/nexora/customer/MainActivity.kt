package com.nexora.customer

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.doOnPreDraw
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import androidx.webkit.WebViewOutcomeReceiver
import androidx.webkit.WebViewStartUpConfig
import androidx.webkit.WebViewStartUpResult
import androidx.webkit.WebViewStartupException
import java.util.concurrent.Executors
import com.nexora.customer.data.SecureSessionStore
import com.razorpay.Checkout
import com.razorpay.PaymentData
import com.razorpay.PaymentResultWithDataListener
import org.json.JSONObject
import java.io.ByteArrayInputStream

/** Shared customer UI, packaged locally: network/authentication never gate the first screen. */
class MainActivity: ComponentActivity(), PaymentResultWithDataListener {
    private lateinit var root:FrameLayout
    private lateinit var status:LinearLayout
    private lateinit var detail:TextView
    private lateinit var spinner:ProgressBar
    private lateinit var retry:Button
    private lateinit var updateWebView:Button
    private var web:WebView?=null
    private var ready=false
    private var destroyed=false
    private val startupExecutor=Executors.newSingleThreadExecutor()
    private var startupInProgress=false
    private var startupGeneration=0
    private val screenTimeout=Runnable {
        if(!destroyed&&!ready)fail("The screen is taking too long. Tap Retry. Your saved account and bookings are kept.")
    }
    private val engineTimeout=Runnable {
        if(!destroyed&&startupInProgress) {
            startupGeneration++
            startupInProgress=false
            fail("Android WebView is taking too long to start. Tap Retry, or update Android System WebView from Google Play.")
        }
    }
    private var legacySession:String?=null
    private val handler=Handler(Looper.getMainLooper())
    private val origins=setOf(LOCAL_ORIGIN,BuildConfig.WEBSITE_URL)
    private var fileCallback:ValueCallback<Array<Uri>>?=null
    private var locationCallback:((Boolean)->Unit)?=null
    private var paymentReply:JavaScriptReplyProxy?=null
    private var paymentId=""
    private var exportReply:JavaScriptReplyProxy?=null
    private var exportId=""
    private var exportBytes:ByteArray?=null
    private val files=registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result.resultCode,result.data));fileCallback=null
    }
    private val location=registerForActivityResult(ActivityResultContracts.RequestPermission()) { allowed -> locationCallback?.invoke(allowed);locationCallback=null }
    private val export=registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        try {
            val uri=result.data?.data
            if(result.resultCode==RESULT_OK&&uri!=null&&exportBytes!=null) {
                contentResolver.openOutputStream(uri)?.use { it.write(exportBytes!!) } ?: error("Cannot open file")
                exportReply?.let { answer(it,exportId,true) };Toast.makeText(this,"File saved",Toast.LENGTH_SHORT).show()
            } else exportReply?.let { answer(it,exportId,false,"Save cancelled") }
        } catch(_:Exception) { exportReply?.let { answer(it,exportId,false,"File could not be saved") } }
        finally { exportBytes=null;exportReply=null }
    }
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        root=FrameLayout(this).apply { setBackgroundColor(Color.rgb(249,247,252)) };setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v,insets -> val bars=insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);insets }
        status=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;gravity=android.view.Gravity.CENTER;setPadding(32,32,32,32);setBackgroundColor(Color.rgb(249,247,252)) }
        status.addView(TextView(this).apply { text="Nexora";textSize=28f;setTextColor(Color.rgb(76,29,149));gravity=android.view.Gravity.CENTER })
        detail=TextView(this).apply { text="Opening your salon app…";textSize=16f;gravity=android.view.Gravity.CENTER;setPadding(0,24,0,24) };status.addView(detail)
        spinner=ProgressBar(this);status.addView(spinner)
        retry=Button(this).apply { text="Retry";visibility=View.GONE;setOnClickListener { loadHome() } };status.addView(retry)
        updateWebView=Button(this).apply { text="Update Android System WebView";visibility=View.GONE;setOnClickListener { openWebViewUpdate() } };status.addView(updateWebView)
        status.addView(Button(this).apply { text="Open website";setOnClickListener { external(Uri.parse(BuildConfig.WEBSITE_URL+"/?app=1")) } })
        root.addView(status,FrameLayout.LayoutParams(-1,-1))
        onBackPressedDispatcher.addCallback(this,object:OnBackPressedCallback(true) { override fun handleOnBackPressed() {
            web?.evaluateJavascript("JSON.stringify({overlay:!!document.querySelector('[role=dialog]'),home:!new URLSearchParams(location.search).has('site')&&!new URLSearchParams(location.search).has('tab')})") { raw ->
                val state=runCatching { JSONObject(org.json.JSONTokener(raw).nextValue().toString()) }.getOrNull()
                if(state?.optBoolean("overlay")==true)web?.evaluateJavascript("(()=>{const d=document.querySelector('[role=dialog]');const b=d?.querySelector('button[aria-label*=Close],button[aria-label*=close]');if(b)b.click()})()",null)
                else if(state?.optBoolean("home")==false)web?.evaluateJavascript("(()=>{const n=document.querySelector('nav[aria-label=\\\"Customer app navigation\\\"]');const b=Array.from(n?.querySelectorAll('button')||[]).find(x=>x.textContent.trim()==='Home');if(b)b.click();else location.href='/?app=1'})()",null)
                else finish()
            } ?: finish()
        } })
        Thread {
            legacySession=runCatching { if(!getPreferences(MODE_PRIVATE).getBoolean("legacy_migrated",false))SecureSessionStore(this).read() else null }.getOrNull()
            runOnUiThread {
                if(!destroyed) {
                    // Let the native screen draw before any Chromium initialization can block it.
                    root.doOnPreDraw { root.post { if(!destroyed)createWeb(savedInstanceState) } }
                    root.invalidate()
                }
            }
        }.start()
    }
    private fun createWeb(saved:Bundle?) {
        if(destroyed||isFinishing||startupInProgress)return
        try {
            val provider=WebViewCompat.getCurrentWebViewPackage(this)
            // Check the package before loading Chromium: old engines can crash inside native
            // WebView code and cannot render the shared UI's modern CSS reliably.
            if(!supportsCustomerWebUi(provider?.versionName)) {
                updateWebView.visibility=View.VISIBLE
                fail("Update Android System WebView, then reopen Nexora or tap Retry. Your saved account is kept.")
                return
            }
            startupInProgress=true
            val generation=++startupGeneration
            ready=false
            status.visibility=View.VISIBLE
            spinner.visibility=View.VISIBLE
            retry.visibility=View.GONE
            detail.text="Opening your salon app…"
            handler.removeCallbacks(engineTimeout)
            handler.postDelayed(engineTimeout,45000)
            WebViewCompat.startUpWebView(applicationContext,
                WebViewStartUpConfig.Builder(startupExecutor).build(),
                object:WebViewOutcomeReceiver<WebViewStartUpResult,WebViewStartupException> {
                    override fun onResult(result:WebViewStartUpResult) {
                        if(destroyed||isFinishing||generation!=startupGeneration)return
                        startupInProgress=false
                        handler.removeCallbacks(engineTimeout)
                        createPreparedWeb(saved)
                    }
                    override fun onError(error:WebViewStartupException) {
                        if(destroyed||generation!=startupGeneration)return
                        startupInProgress=false
                        handler.removeCallbacks(engineTimeout)
                        fail("Android WebView could not start. Tap Retry, or update Android System WebView from Google Play.")
                    }
                })
        } catch(_:Exception) {
            startupInProgress=false
            handler.removeCallbacks(engineTimeout)
            fail("Nexora could not start. Retry, or update Android System WebView from Google Play.")
        }
    }
    private fun createPreparedWeb(saved:Bundle?) {
        try {
            if(!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) { updateWebView.visibility=View.VISIBLE;fail("Please update Android System WebView, then tap Retry.");return }
            updateWebView.visibility=View.GONE
            val view=WebView(this);web=view;view.id=R.id.customer_web;view.setBackgroundColor(Color.rgb(249,247,252))
            view.settings.apply { javaScriptEnabled=true;domStorageEnabled=true;allowFileAccess=false;allowContentAccess=false;mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW;javaScriptCanOpenWindowsAutomatically=false;setSupportMultipleWindows(true);mediaPlaybackRequiresUserGesture=true;userAgentString=userAgentString+" NexoraAndroid/"+BuildConfig.VERSION_NAME }
            CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(view,false)
            WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
            val loader=WebViewAssetLoader.Builder().addPathHandler("/",WebViewAssetLoader.PathHandler { raw ->
                val path=raw.ifEmpty { "index.html" }
                if(path.contains("..")||path.startsWith('/'))null else try {
                    val mime=when(path.substringAfterLast('.')) { "html"->"text/html";"js"->"application/javascript";"css"->"text/css";"json","webmanifest"->"application/json";"svg"->"image/svg+xml";"png"->"image/png";"jpg","jpeg"->"image/jpeg";"webp"->"image/webp";"woff2"->"font/woff2";else->"application/octet-stream" }
                    WebResourceResponse(mime,"UTF-8",200,"OK",mapOf("Cache-Control" to "no-cache"),assets.open("web/$path"))
                } catch(_:Exception) { WebResourceResponse("text/plain","UTF-8",404,"Not Found",emptyMap(),ByteArrayInputStream("Not found".toByteArray())) }
            }).build()
            WebViewCompat.addWebMessageListener(view,"NexoraNative",origins) { _,message,origin,main,proxy ->
                if(main&&origin.toString() in origins) {
                    val data=runCatching { val text=message.data.orEmpty();require(text.length<=15000000);JSONObject(text) }.getOrNull()
                    if(data!=null)runCatching { nativeAction(data,proxy) }.onFailure { answer(proxy,data.optString("id"),false,"Android action could not complete") }
                }
            }
            val migration=legacySession?.let { "try{if(!localStorage.getItem('studioflow_supabase_session'))localStorage.setItem('studioflow_supabase_session',${JSONObject.quote(it)});NexoraNative.postMessage(JSON.stringify({action:'migrated'}));}catch(e){}" }.orEmpty()
            if(WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT))WebViewCompat.addDocumentStartJavaScript(view,"if(window.top===window){$migration}",origins)
            view.webViewClient=object:WebViewClient() {
                override fun shouldInterceptRequest(v:WebView,r:WebResourceRequest)=loader.shouldInterceptRequest(r.url)
                override fun shouldOverrideUrlLoading(v:WebView,r:WebResourceRequest):Boolean {
                    if(!r.isForMainFrame)return false
                    val uri=r.url
                    if(uri.scheme=="https"&&uri.host=="appassets.androidplatform.net")return false
                    if(uri.scheme=="https"&&uri.host==Uri.parse(BuildConfig.WEBSITE_URL).host&&uri.getQueryParameter("app")!=null) { v.loadUrl(LOCAL_ORIGIN+uri.encodedPath.orEmpty()+"?"+uri.encodedQuery.orEmpty()+uri.encodedFragment?.let{"#$it"}.orEmpty());return true }
                    external(uri);return true
                }
                override fun onPageFinished(v:WebView,url:String) {
                    if(!trusted(url))return
                    if(migration.isNotBlank()&&legacySession!=null&&!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) { legacySession=null;v.evaluateJavascript("$migration;location.reload()",null);return }
                    v.evaluateJavascript("!!document.querySelector('.cr-app,main[role=alert]')") { if(it=="true")shown() }
                }
                override fun onReceivedError(v:WebView,r:WebResourceRequest,e:WebResourceError) { if(r.isForMainFrame)fail("The app screen could not load. Retry to reopen your saved app.") }
                override fun onRenderProcessGone(v:WebView,d:RenderProcessGoneDetail):Boolean { root.removeView(v);v.destroy();web=null;fail("Android closed the screen. Tap Retry to reopen Nexora.");return true }
            }
            view.webChromeClient=object:WebChromeClient() {
                override fun onShowFileChooser(v:WebView,callback:ValueCallback<Array<Uri>>,params:FileChooserParams):Boolean {
                    if(!trusted(v.url))return false
                    fileCallback?.onReceiveValue(null);fileCallback=callback
                    return try { files.launch(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE);type="image/*";putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("image/jpeg","image/png","image/webp","application/pdf")) });true } catch(_:Exception) { callback.onReceiveValue(null);fileCallback=null;true }
                }
                override fun onGeolocationPermissionsShowPrompt(origin:String,callback:GeolocationPermissions.Callback) {
                    if(origin.trimEnd('/') !in origins) { callback.invoke(origin,false,false);return }
                    if(checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED)callback.invoke(origin,true,false)
                    else { locationCallback={allowed->callback.invoke(origin,allowed,false)};location.launch(Manifest.permission.ACCESS_COARSE_LOCATION) }
                }
                override fun onPermissionRequest(request:PermissionRequest) { request.deny() }
                override fun onCreateWindow(v:WebView,isDialog:Boolean,isUserGesture:Boolean,result:android.os.Message):Boolean {
                    if(!isUserGesture)return false
                    val popup=WebView(this@MainActivity);popup.webViewClient=object:WebViewClient() { override fun shouldOverrideUrlLoading(view:WebView,url:String):Boolean { external(Uri.parse(url));view.destroy();return true } }
                    (result.obj as WebView.WebViewTransport).webView=popup;result.sendToTarget();return true
                }
            }
            root.addView(view,0,FrameLayout.LayoutParams(-1,-1))
            if(saved?.getBundle("web")?.let { view.restoreState(it) }==null)loadHome() else watchReady()
        } catch(_:Exception) { fail("Nexora could not start. Retry, or update Android System WebView from Google Play.") }
    }
    private fun trusted(url:String?)=runCatching { val u=Uri.parse(url);u.scheme=="https"&&("https://"+u.host) in origins }.getOrDefault(false)
    private fun loadHome() { if(web==null){spinner.visibility=View.VISIBLE;createWeb(null);return};ready=false;status.visibility=View.VISIBLE;spinner.visibility=View.VISIBLE;retry.visibility=View.GONE;detail.text="Opening your salon app…";web?.loadUrl(startUrl(intent?.data));watchReady() }
    private fun watchReady() { handler.removeCallbacks(screenTimeout);handler.postDelayed(screenTimeout,20000) }
    private fun shown() { if(destroyed)return;ready=true;handler.removeCallbacks(screenTimeout);status.visibility=View.GONE }
    private fun fail(text:String) { handler.removeCallbacks(screenTimeout);ready=false;status.visibility=View.VISIBLE;detail.text=text;spinner.visibility=View.GONE;retry.visibility=View.VISIBLE }
    private fun answer(proxy:JavaScriptReplyProxy,id:String,ok:Boolean,error:String="") { runCatching { proxy.postMessage(JSONObject().put("id",id).put("ok",ok).put("error",error).toString()) } }
    private fun nativeAction(data:JSONObject,proxy:JavaScriptReplyProxy) {
        val id=data.optString("id")
        when(data.optString("action")) {
            "ready"->shown()
            "migrated"->{getPreferences(MODE_PRIVATE).edit().putBoolean("legacy_migrated",true).apply();legacySession=null;Thread { runCatching { SecureSessionStore(this).write(null) } }.start()}
            "copy"->{getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Nexora",data.optString("text").take(30000)));answer(proxy,id,true)}
            "share"->{startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="text/plain";putExtra(Intent.EXTRA_TEXT,data.optString("text").take(30000)) },"Share Nexora"));answer(proxy,id,true)}
            "saveFile"->{if(exportBytes!=null){answer(proxy,id,false,"Finish saving the previous file first");return};val bytes=Base64.decode(data.optString("base64"),Base64.DEFAULT);require(bytes.size<=10*1024*1024);exportBytes=bytes;exportReply=proxy;exportId=id;export.launch(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE);type=data.optString("type").substringBefore(';').trim().ifBlank{"text/plain"};putExtra(Intent.EXTRA_TITLE,data.optString("name").replace(Regex("[^a-zA-Z0-9._-]"),"_").take(120)) })}
            "payment"->{if(paymentReply!=null){answer(proxy,id,false,"Checkout is already open");return};val options=data.getJSONObject("options");require(options.optString("key").startsWith("rzp_")&&options.optString("order_id").startsWith("order_")&&options.optLong("amount")>0);paymentReply=proxy;paymentId=id;try { Checkout().apply { setKeyID(options.getString("key"));setImage(R.drawable.ic_nexora) }.open(this,options.put("name","Nexora").put("description","25% booking advance")) } catch(_:Exception) { paymentResult(false,JSONObject().put("error","Checkout did not open. Recheck payment status.")) }}
        }
    }
    private fun paymentResult(ok:Boolean,response:JSONObject) { paymentReply?.let { runCatching { it.postMessage(JSONObject().put("id",paymentId).put("event","payment").put("ok",ok).put("response",response).toString()) } };paymentReply=null }
    override fun onPaymentSuccess(paymentId:String?,data:PaymentData?) { paymentResult(paymentId!=null&&data?.orderId!=null&&data.signature!=null,JSONObject().put("razorpay_payment_id",paymentId).put("razorpay_order_id",data?.orderId).put("razorpay_signature",data?.signature)) }
    override fun onPaymentError(code:Int,response:String?,data:PaymentData?) { paymentResult(false,JSONObject().put("error","Payment did not complete. Recheck payment status.")) }
    private fun external(uri:Uri) { if(uri.scheme !in setOf("https","tel","mailto","geo","upi","intent","market"))return;try { val out=if(uri.scheme=="intent")Intent.parseUri(uri.toString(),Intent.URI_INTENT_SCHEME).apply { addCategory(Intent.CATEGORY_BROWSABLE);component=null;selector=null;action=Intent.ACTION_VIEW } else Intent(Intent.ACTION_VIEW,uri);startActivity(out) } catch(_:Exception) { Toast.makeText(this,"No app is available to open this link.",Toast.LENGTH_LONG).show() } }
    private fun openWebViewUpdate() {
        val provider=WebViewCompat.getCurrentWebViewPackage(this)?.packageName
        val packageName=if(provider=="com.android.chrome")provider else "com.google.android.webview"
        try { startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id=$packageName"))) }
        catch(_:Exception) { external(Uri.parse("https://play.google.com/store/apps/details?id=$packageName")) }
    }
    private fun startUrl(uri:Uri?):String { val u=Uri.parse(LOCAL_ORIGIN).buildUpon().appendQueryParameter("app","1");if(uri?.scheme=="nexora"&&uri.host=="salon")u.appendQueryParameter("site",uri.lastPathSegment);if(uri?.scheme=="nexora"&&uri.host=="referral")u.appendQueryParameter("auth","signup").appendQueryParameter("customer_ref",uri.lastPathSegment);return u.build().toString() }
    override fun onNewIntent(intent:Intent) { super.onNewIntent(intent);setIntent(intent);web?.loadUrl(startUrl(intent.data)) }
    override fun onSaveInstanceState(outState:Bundle) { web?.let { val b=Bundle();it.saveState(b);outState.putBundle("web",b) };super.onSaveInstanceState(outState) }
    override fun onPause() {
        web?.let { view ->
            view.onPause()
            // Do not initialize Chromium when leaving the native startup screen;
            // persisting cookies can also perform disk I/O and must not block input.
            val cookies=CookieManager.getInstance()
            if(!startupExecutor.isShutdown)startupExecutor.execute { runCatching { cookies.flush() } }
        }
        super.onPause()
    }
    override fun onResume() { super.onResume();web?.onResume() }
    override fun onDestroy() { destroyed=true;startupGeneration++;startupExecutor.shutdown();handler.removeCallbacksAndMessages(null);fileCallback?.onReceiveValue(null);locationCallback?.invoke(false);web?.let { root.removeView(it);it.destroy() };super.onDestroy() }
    companion object { const val LOCAL_ORIGIN="https://appassets.androidplatform.net" }
}
