package com.nexora.customer.notifications

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.firebase.messaging.FirebaseMessaging
import com.nexora.customer.BuildConfig
import kotlinx.coroutines.tasks.await

class ConsentManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("privacy", Context.MODE_PRIVATE)
    val analytics get() = prefs.getBoolean("analytics", false)
    val crashes get() = prefs.getBoolean("crashes", false)
    val pushes get() = prefs.getBoolean("pushes", false)
    private fun ready() = BuildConfig.FIREBASE_ENABLED && FirebaseApp.getApps(context).isNotEmpty()
    fun applySavedConsent() {
        if(!ready()) return
        FirebaseAnalytics.getInstance(context).setAnalyticsCollectionEnabled(analytics)
        FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(crashes)
        FirebaseMessaging.getInstance().isAutoInitEnabled = pushes
        if(!crashes) FirebaseCrashlytics.getInstance().deleteUnsentReports()
    }
    fun analytics(enabled: Boolean) { prefs.edit().putBoolean("analytics", enabled).apply(); if(ready()) { val analytics = FirebaseAnalytics.getInstance(context); analytics.setAnalyticsCollectionEnabled(enabled); if(!enabled) analytics.resetAnalyticsData() } }
    fun crashes(enabled: Boolean) { prefs.edit().putBoolean("crashes", enabled).apply(); if(ready()) { FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(enabled); if(!enabled) FirebaseCrashlytics.getInstance().deleteUnsentReports() } }
    suspend fun startPush(): String {
        check(ready()) { "Push notifications require this app's Firebase configuration." }
        FirebaseMessaging.getInstance().isAutoInitEnabled = true
        val token = FirebaseMessaging.getInstance().token.await()
        prefs.edit().putBoolean("pushes", true).putString("token", token).commit()
        return token
    }
    fun cachedToken() = prefs.getString("token", null)
    suspend fun stopPush() { prefs.edit().putBoolean("pushes", false).remove("token").commit(); if(ready()) { FirebaseMessaging.getInstance().isAutoInitEnabled = false; FirebaseMessaging.getInstance().deleteToken().await() } }
}
