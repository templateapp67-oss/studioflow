package com.nexora.customer.data

import com.nexora.customer.domain.*
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject

interface AuthRepository {
    val customer: StateFlow<Customer?>
    suspend fun signIn(email: String, password: String)
    suspend fun signUp(name: String, email: String, password: String, whatsapp: String, birthDate: String, referral: String): Boolean
    suspend fun resetPassword(email: String)
    suspend fun signOut()
}
interface SalonRepository { suspend fun salons(): List<Salon>; suspend fun reviews(slug: String): List<Review>; suspend fun review(slug: String, name: String, rating: Int, comment: String) }
interface BookingRepository {
    suspend fun slots(selection: Selection): List<Slot>
    suspend fun availability(selection: Selection): BookingAvailability
    suspend fun reserve(selection: Selection, requestId: String): Booking
    suspend fun bookings(): List<Booking>
    suspend fun reschedule(id: String, selection: Selection): Booking
    suspend fun cancel(id: String)
    suspend fun order(id: String): PaymentOrder
    suspend fun verify(id: String, order: String, payment: String, signature: String)
    suspend fun reconcile(id: String)
    suspend fun qr(id: String): QrOrder
    suspend fun reconcileQr(id: String)
}
interface CustomerRepository {
    suspend fun favorites(): Set<String>
    suspend fun favorite(slug: String, enabled: Boolean)
    suspend fun profile(): JSONObject
    suspend fun updateProfile(name: String, phone: String, whatsapp: String, birthDate: String)
    suspend fun upload(bytes: ByteArray, mime: String, document: Boolean): String
    suspend fun rewards(): List<Reward>
    suspend fun referral(): String
    suspend fun applyReferral(code: String)
    suspend fun registerToken(token: String)
    suspend fun revokeToken(token: String)
}
