package com.nexora.customer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.compose.*
import com.nexora.customer.domain.PaymentOrder

@Composable fun CustomerApp(vm: CustomerViewModel, pay: (PaymentOrder) -> Unit, initialSalon: String?, initialReferral: String?) {
    val s by vm.state.collectAsStateWithLifecycle()
    val nav = rememberNavController()
    LaunchedEffect(s.selection.slug, s.selection.slot, s.slotsLoading) {
        if(nav.currentDestination?.route == "summary" && s.selection.slot == null && s.activeBooking == null) nav.popBackStack("booking", false)
    }
    val current by nav.currentBackStackEntryAsState()
    val route = current?.destination?.route ?: "home"
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(s.message, s.error) { (s.error ?: s.message)?.let { snackbar.showSnackbar(it); vm.clearMessage() } }
    LaunchedEffect(initialSalon) { initialSalon?.let { vm.openSalon(it); nav.navigate("salon") } }
    LaunchedEffect(initialReferral, s.customer?.id) { if(initialReferral != null) { if(s.customer != null) vm.referral(initialReferral) else nav.navigate("auth") { launchSingleTop = true } } }
    val lifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
    LaunchedEffect(lifecycle, route) {
        lifecycle.repeatOnLifecycle(androidx.lifecycle.Lifecycle.State.STARTED) {
            while(true) {
                vm.refresh()
                if(vm.state.value.customer != null) vm.account()
                kotlinx.coroutines.delay(30000)
                if(route == "booking" && vm.state.value.selection.slot == null && !vm.state.value.slotsLoading) vm.loadSlots()
            }
        }
    }
    Scaffold(snackbarHost = { SnackbarHost(snackbar) }, bottomBar = {
        if(route in listOf("home", "bookings", "rewards", "favorites", "profile")) NavigationBar {
            listOf(Triple("home", "Home", Icons.Outlined.Home), Triple("bookings", "Bookings", Icons.Outlined.DateRange), Triple("rewards", "Rewards", Icons.Outlined.Star), Triple("favorites", "Favorites", Icons.Outlined.FavoriteBorder), Triple("profile", "Profile", Icons.Outlined.Person)).forEach { (target, label, icon) ->
                NavigationBarItem(selected = route == target, onClick = { nav.navigate(target) { popUpTo("home") { saveState = true }; launchSingleTop = true; restoreState = true }; if(target in listOf("bookings", "profile", "rewards") && s.customer != null) vm.account() }, icon = { Icon(icon, label) }, label = { Text(label, maxLines = 1) })
            }
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if(s.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            NavHost(nav, startDestination = "home", modifier = Modifier.weight(1f)) {
                composable("home") { DiscoveryScreen(s, vm, false) { vm.openSalon(it); nav.navigate("salon") } }
                composable("favorites") { DiscoveryScreen(s, vm, true) { vm.openSalon(it); nav.navigate("salon") } }
                composable("salon") { SalonScreen(s, vm, { nav.popBackStack() }, { nav.navigate(if(s.customer == null) "auth" else "booking") }) }
                composable("booking") { BookingScreen(s, vm, { nav.popBackStack() }) { nav.navigate("summary") } }
                composable("summary") { SummaryScreen(s, vm, { nav.popBackStack() }) { nav.navigate("payment") } }
                composable("payment") { PaymentScreen(s, vm, { nav.navigate("bookings") { popUpTo("home") } }) { vm.preparePayment(pay) } }
                composable("bookings") { BookingsScreen(s, vm, { nav.navigate("auth") }, { b -> vm.openPayment(b); nav.navigate("payment") }, { b -> val salon = s.salons.find { it.ownerId == b.ownerId }; salon?.let { vm.openSalon(it.slug); vm.editSelection { selection -> selection.copy(serviceIds = b.serviceIds.ifEmpty { setOf(b.serviceId) }) }; nav.navigate("booking") } }, { b -> vm.startReschedule(b); nav.navigate("booking") }) }
                composable("rewards") { RewardsScreen(s, vm) { nav.navigate("auth") } }
                composable("profile") { ProfileScreen(s, vm) { nav.navigate("auth") } }
                composable("auth") { AuthScreen(s, vm, { if(s.selection.slug.isNotBlank()) nav.navigate("booking") else nav.popBackStack() }, initialReferral) }
            }
        }
    }
}
@Composable fun PageTitle(title: String, subtitle: String? = null, back: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        back?.let { IconButton(onClick = it) { Icon(Icons.Outlined.ArrowBack, "Back") } }
        Column { Text(title, style = MaterialTheme.typography.headlineSmall); subtitle?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
    }
}
@Composable fun EmptyState(text: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { Text(text); if(action != null && onAction != null) OutlinedButton(onClick = onAction) { Text(action) } }
}
