package com.nexora.customer.ui

import android.app.DatePickerDialog
import android.Manifest
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.Role
import com.nexora.customer.R
import com.nexora.customer.data.detail
import com.nexora.customer.domain.*
import java.time.LocalDate
import java.time.ZoneId
import java.util.Calendar
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.nexora.customer.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable fun AuthScreen(s: CustomerState, vm: CustomerViewModel, signedIn: () -> Unit, initialReferral: String? = null) {
    var passwordVisible by remember { mutableStateOf(false) }
    var signup by rememberSaveable { mutableStateOf(initialReferral != null) }; var whatsapp by rememberSaveable { mutableStateOf("+91") }; var birthDate by rememberSaveable { mutableStateOf("") }; var referral by rememberSaveable { mutableStateOf(initialReferral.orEmpty()) }; var email by rememberSaveable { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var name by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(s.customer?.id) { if(s.customer != null) { password = ""; signedIn() } }
    LazyColumn(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item { Spacer(Modifier.height(32.dp)); Text("NEXORA", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge); PageTitle(if(signup) "Your next chapter in self-care" else "Welcome back", "One account. Every salon. Your time.") }
        if(signup) item { OutlinedTextField(name, { name = it }, label = { Text("Full name") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
        if(signup) item { OutlinedTextField(whatsapp, { whatsapp = it }, label = { Text("Mobile / WhatsApp number (+91) · required") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.fillMaxWidth()); BirthDateField(birthDate, { birthDate = it }, required = true); OutlinedTextField(referral, { referral = it }, label = { Text("Referral code") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(email, { email = it }, label = { Text("Email") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), singleLine = true, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(password, { password = it }, label = { Text("Password") }, visualTransformation = if(passwordVisible) VisualTransformation.None else PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), trailingIcon = { IconButton(onClick = { passwordVisible = !passwordVisible }) { Icon(painterResource(if(passwordVisible) R.drawable.ic_eye_off else R.drawable.ic_eye), if(passwordVisible) "Hide password" else "Show password") } }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
        item { Button(onClick = { if(signup) vm.signUp(name, email, password, whatsapp, birthDate, referral) else vm.signIn(email, password) }, enabled = !s.busy && email.contains('@') && (if(signup) password.length >= 8 else password.isNotBlank()), modifier = Modifier.fillMaxWidth()) { Text(if(signup) "Create account" else "Sign in") }; TextButton(onClick = { signup = !signup; password = ""; passwordVisible = false }) { Text(if(signup) "Already a member? Sign in" else "New here? Create account") }; TextButton(onClick = { vm.resetPassword(email) }, enabled = !s.busy) { Text("Forgot password?") } }
        item { Text("Use the same account you use on a salon website. Optional analytics and crash reporting are off until you choose otherwise.", style = MaterialTheme.typography.bodySmall) }
    }
}
@Composable fun RewardsScreen(s: CustomerState, vm: CustomerViewModel, signIn: () -> Unit) {
    val context = LocalContext.current; var code by remember { mutableStateOf("") }
    if(s.customer == null) { EmptyState("Sign in to view loyalty points and referral links.", "Sign in", signIn); return }
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { PageTitle("Good things come back", "Your loyalty & referrals") }
        if(s.rewards.isEmpty()) item { EmptyState("Your completed eligible salon visits will appear here. Rewards follow each salon's published program.") }
        items(s.rewards) { reward -> SummaryCard(reward.salon, "${reward.points} points\n${reward.description}") }
        item { SummaryCard("YOUR REFERRAL CODE", s.referral.ifBlank { "Loading…" }); Button(onClick = { share(context, "Discover your next salon with Nexora. My referral code: ${s.referral}\n${BuildConfig.WEBSITE_URL}/?app=1&auth=signup&customer_ref=${android.net.Uri.encode(s.referral)}") }, enabled = s.referral.isNotBlank()) { Text("Share referral link") } }
        item { OutlinedTextField(code, { code = it }, label = { Text("Invited by a friend? Enter their code") }, modifier = Modifier.fillMaxWidth()); OutlinedButton(onClick = { vm.referral(code) }, enabled = code.isNotBlank() && !s.busy) { Text("Link referral") }; Text("Customer referrals are tracked separately from business partner commissions. Rewards are awarded only under an enabled program; no cash credit is promised.", style = MaterialTheme.typography.bodySmall) }
    }
}
@Composable fun ProfileScreen(s: CustomerState, vm: CustomerViewModel, signIn: () -> Unit) {
    if(s.customer == null) { EmptyState("Your profile, preferences and private uploads.", "Sign in / Sign up", signIn); return }
    if(!s.profileLoaded) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Loading your saved profile…")
            if(s.busy) CircularProgressIndicator() else OutlinedButton(onClick = { vm.account() }) { Text("Retry loading profile") }
        }
        return
    }
    val context = LocalContext.current; val scope = rememberCoroutineScope()
    var name by remember(s.profile.detail("full_name")) { mutableStateOf(s.profile.detail("full_name").ifBlank { s.customer.name }) }
    var phone by remember(s.profile.detail("phone")) { mutableStateOf(s.profile.detail("phone").ifBlank { s.profile.detail("whatsapp_number") }) }
    var whatsapp by remember(s.profile.detail("whatsapp_number")) { mutableStateOf(s.profile.detail("whatsapp_number").ifBlank { "+91" }) }
    var birthDate by remember(s.profile.detail("date_of_birth")) { mutableStateOf(s.profile.detail("date_of_birth")) }
    var uploadError by remember { mutableStateOf<String?>(null) }
    var analytics by remember { mutableStateOf(vm.container.consent.analytics) }; var crashes by remember { mutableStateOf(vm.container.consent.crashes) }; var push by remember { mutableStateOf(vm.container.consent.pushes) }
    fun readUpload(uri: android.net.Uri?, document: Boolean) {
        if(uri == null) return
        scope.launch { try {
            val mime = context.contentResolver.getType(uri) ?: error("Cannot determine file type")
            val bytes = withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                while(output.size() <= 5*1024*1024) {
                    val count = input.read(buffer, 0, minOf(buffer.size, 5*1024*1024+1-output.size()))
                    if(count < 0) break
                    output.write(buffer, 0, count)
                }
                output.toByteArray() } ?: error("File unavailable") }
            require(bytes.size <= 5*1024*1024) { "Choose a file smaller than 5 MB" }
            vm.upload(bytes, mime, document)
        } catch(e: Exception) { uploadError = e.message } }
    }
    val photo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { readUpload(it, false) }
    val document = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { readUpload(it, true) }
    val notifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { allowed -> if(allowed) { vm.enablePush(); push = true } }
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { PageTitle("Your profile", s.customer.email); Text("Nexora ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodySmall) }
        item { OutlinedTextField(name, { name = it }, label = { Text("Full name") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(phone, { phone = it }, label = { Text("Mobile number") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.fillMaxWidth()); OutlinedTextField(whatsapp, { whatsapp = it }, label = { Text("WhatsApp number (+91)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.fillMaxWidth()); BirthDateField(birthDate, { birthDate = it }); Button(onClick = { vm.profile(name, phone, whatsapp, birthDate) }, enabled = !s.busy) { Text("Save profile") } }
        item { Text("Private files", style = MaterialTheme.typography.titleMedium); Text("Upload only your own profile photo or documents the salon has requested and you are permitted to provide. JPEG, PNG or PDF · 5 MB maximum.", style = MaterialTheme.typography.bodySmall); OutlinedButton(onClick = { photo.launch(arrayOf("image/jpeg", "image/png")) }, enabled = !s.busy) { Text("Upload profile photo") }; OutlinedButton(onClick = { document.launch(arrayOf("application/pdf", "image/jpeg", "image/png")) }, enabled = !s.busy) { Text("Upload permitted document") }; if(s.profile.optString("photo_path").isNotBlank() && s.profile.optString("photo_path") != "null") Text("Profile photo saved privately."); if(s.profile.optString("photo_url").isNotBlank()) coil.compose.AsyncImage(s.profile.optString("photo_url"), "Your private profile photograph", Modifier.size(100.dp)); uploadError?.let { Text(it, color = MaterialTheme.colorScheme.error) } }
        item { Text("Privacy & notifications", style = MaterialTheme.typography.titleMedium); Text("Optional diagnostics may collect device and app usage information. Consent can be withdrawn here at any time. Booking and document contents are excluded.", style = MaterialTheme.typography.bodySmall) }
        item { ConsentRow("Usage analytics", analytics, BuildConfig.FIREBASE_ENABLED) { analytics = it; vm.container.consent.analytics(it) }; ConsentRow("Crash reporting", crashes, BuildConfig.FIREBASE_ENABLED) { crashes = it; vm.container.consent.crashes(it) }; ConsentRow("Booking notifications", push, BuildConfig.FIREBASE_ENABLED && !s.busy) { enabled -> if(enabled) { if(Build.VERSION.SDK_INT >= 33) notifications.launch(Manifest.permission.POST_NOTIFICATIONS) else { vm.enablePush(); push = true } } else { vm.disablePush(); push = false } }; if(!BuildConfig.FIREBASE_ENABLED) Text("Notifications and optional diagnostics are not available in this version.", style = MaterialTheme.typography.bodySmall) }
        item { TextButton(onClick = { vm.signOut() }, enabled = !s.busy) { Text("Sign out") } }
    }
}
@Composable private fun ConsentRow(label: String, checked: Boolean, enabled: Boolean, change: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, Modifier.weight(1f).padding(top = 12.dp)); Switch(checked, change, enabled = enabled) } }

/** The field and its calendar button both open the platform calendar, without typed ISO dates. */
@Composable private fun BirthDateField(value: String, change: (String) -> Unit, required: Boolean = false) {
    val context = LocalContext.current
    val today = LocalDate.now(ZoneId.of("Asia/Kolkata"))
    fun showCalendar() {
        val selected = runCatching { LocalDate.parse(value) }.getOrNull()?.takeIf { validBirthDate(it.toString(), today) } ?: today.minusYears(18)
        DatePickerDialog(context, { _, year, month, day -> change(LocalDate.of(year, month + 1, day).toString()) }, selected.year, selected.monthValue - 1, selected.dayOfMonth).apply {
            fun millis(date: LocalDate) = Calendar.getInstance().apply { clear(); set(date.year, date.monthValue - 1, date.dayOfMonth, 12, 0, 0) }.timeInMillis
            datePicker.minDate = millis(LocalDate.of(1900, 1, 1))
            datePicker.maxDate = millis(today)
        }.show()
    }
    Box(Modifier.fillMaxWidth()) {
        OutlinedTextField(displayBirthDate(value), {}, readOnly = true, label = { Text("Date of Birth (DD-MM-YYYY)" + if(required) " · required" else "") }, trailingIcon = { Icon(painterResource(R.drawable.ic_calendar), null) }, modifier = Modifier.fillMaxWidth())
        Box(Modifier.matchParentSize().semantics { contentDescription = "Date of Birth: " + displayBirthDate(value).ifBlank { "Choose date" } }.clickable(role = Role.Button, onClickLabel = "Choose date of birth", onClick = { showCalendar() }))
    }
}
