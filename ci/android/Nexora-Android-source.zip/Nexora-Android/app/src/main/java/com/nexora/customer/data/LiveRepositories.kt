package com.nexora.customer.data

import com.nexora.customer.domain.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.util.UUID

fun JSONObject.detail(key: String) = cleanDetail(if(isNull(key)) null else optString(key))
fun JSONArray.objects() = (0 until length()).mapNotNull { optJSONObject(it) }
fun JSONArray.strings() = (0 until length()).map { optString(it) }
private fun JSONObject.money(key: String) = optString(key, "0").toBigDecimalOrNull() ?: BigDecimal.ZERO
private fun JSONObject.toCustomer() = Customer(getString("id"), optString("email"), optJSONObject("user_metadata")?.detail("full_name").orEmpty())
fun booking(row: JSONObject): Booking {
    val data = row.optJSONObject("payload") ?: row
    return Booking(row.optString("id", data.optString("id")), row.optString("owner_id"), row.optString("status", data.optString("status")), data.optString("serviceName"), data.optString("serviceId"), data.optString("date"), data.optString("time"), data.optString("stylistName"), data.money("servicePrice"), data.money("amountPaid"), row.optString("hold_expires_at").takeIf { it.isNotBlank() && it != "null" }, data.optBoolean("refund_required"), data.optJSONArray("serviceItems")?.objects()?.map { it.optString("id") }?.toSet() ?: setOf(data.optString("serviceId")))
}
class LiveAuth(private val api: SupabaseApi): AuthRepository {
    private val state: MutableStateFlow<Customer?> = MutableStateFlow(api.session?.optJSONObject("user")?.toCustomer())
    override val customer: StateFlow<Customer?> = state.asStateFlow()
    private val authScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    init { authScope.launch { api.sessionFlow.collect { state.value = it?.optJSONObject("user")?.toCustomer() } } }
    private fun accept(value: JSONObject) { api.saveSession(value.apply { put("expires_at", System.currentTimeMillis() / 1000 + optLong("expires_in", 3600)) }); state.value = value.getJSONObject("user").toCustomer() }
    override suspend fun signIn(email: String, password: String) { accept(JSONObject(api.request("POST", "/auth/v1/token", JSONObject().put("email", email.trim()).put("password", password), mapOf("grant_type" to "password"), false))) }
    override suspend fun signUp(name: String, email: String, password: String, whatsapp: String, birthDate: String, referral: String): Boolean {
        val response = JSONObject(api.request("POST", "/auth/v1/signup", JSONObject().put("email", email.trim()).put("password", password).put("data", JSONObject().put("full_name", name.trim()).put("source", "nexora_android").put("phone", whatsapp).put("whatsapp_number", whatsapp).put("date_of_birth", birthDate).put("customer_referral_code", referral)), authenticated = false))
        if (response.has("access_token")) { accept(response); return true }; return false
    }
    override suspend fun resetPassword(email: String) { api.request("POST", "/auth/v1/recover", JSONObject().put("email", email.trim()), authenticated = false) }
    override suspend fun signOut() { try { api.request("POST", "/auth/v1/logout", query = mapOf("scope" to "local")) } finally { api.saveSession(null); state.value = null } }
}
class LiveSalons(private val api: SupabaseApi): SalonRepository {
    override suspend fun salons(): List<Salon> = JSONObject(api.rpc("studioflow_customer_catalog")).getJSONArray("salons").objects().map { row ->
        val content = row.getJSONObject("content"); val p = content.getJSONObject("profile")
        val promo = p.optJSONObject("promoCampaign")?.takeIf { it.optBoolean("enabled") }?.let { Promotion(it.optString("headline"), it.optString("customOfferText"), it.optString("imageUrl"), it.optString("promoCode")) }
        Salon(row.getString("owner_id"), row.getString("slug"), p.optString("businessName"), p.optString("businessType"), p.optString("city"), p.optString("address"), p.optString("about"), p.optString("phone"), p.optString("coverImageUrl"), p.optDouble("latitude").takeUnless { it.isNaN() }, p.optDouble("longitude").takeUnless { it.isNaN() },
            (content.optJSONArray("services") ?: JSONArray()).objects().map { Service(it.getString("id"), it.optString("name"), it.optString("category"), it.money("price"), it.optInt("durationMinutes"), it.optString("description"), it.optString("imageUrl")) },
            (content.optJSONArray("stylists") ?: JSONArray()).objects().map { Specialist(it.getString("id"), it.optString("name"), it.optString("role"), it.optString("avatarUrl"), (it.optJSONArray("expertiseServiceIds") ?: it.optJSONArray("assignedServices"))?.strings().orEmpty(), it.optInt("experienceYears"), it.optString("bio"), it.optJSONArray("workGallery")?.objects().orEmpty().map { photo -> StaffWork(photo.optString("imageUrl"), photo.optString("caption")) }.filter { photo -> photo.image.startsWith("https://") }) },
            content.optJSONArray("gallery")?.strings().orEmpty(), promo,
            p.optJSONArray("socialVideos")?.objects().orEmpty().map { PromoVideo(it.optString("title"), it.optString("thumbnailUrl"), it.optString("youtubeUrl"), it.optString("previewVideoUrl")) },
            content.optJSONObject("policies")?.let { listOf("cancellation", "lateArrival", "refund").map { key -> it.optString(key) }.filter { value -> value.isNotBlank() }.joinToString("\n\n") }.orEmpty())
    }
    override suspend fun reviews(slug: String) = JSONObject(api.rpc("studioflow_list_reviews", JSONObject().put("p_slug", slug))).getJSONArray("reviews").objects().map { Review(it.optString("name"), it.optInt("rating"), it.optString("comment"), it.optBoolean("verified"), it.optString("imageUrl").takeIf { url -> url.startsWith("https://") }.orEmpty()) }
    override suspend fun review(slug: String, name: String, rating: Int, comment: String) { api.rpc("studioflow_android_review", JSONObject().put("p_slug", slug).put("p_name", name).put("p_rating", rating).put("p_comment", comment)) }
}
class LiveBookings(private val api: SupabaseApi): BookingRepository {
    override suspend fun slots(selection: Selection) = JSONArray(api.rpc("studioflow_android_slots", JSONObject().put("p_slug", selection.slug).put("p_services", JSONArray(selection.serviceIds.toList())).put("p_date", selection.date).put("p_stylist", selection.stylistId))).objects().map { Slot(it.getString("time"), it.getString("label"), it.getString("stylistId")) }
    override suspend fun availability(selection: Selection): BookingAvailability {
        val result = JSONObject(api.rpc("studioflow_booking_availability", JSONObject().put("p_slug", selection.slug).put("p_services", JSONArray(selection.serviceIds.toList())).put("p_date", selection.date).put("p_stylist", selection.stylistId)))
        fun times(key: String) = result.getJSONArray(key).objects().map { Slot(it.getString("time"), it.getString("label"), it.getString("stylistId")) }
        return BookingAvailability(result.getJSONArray("specialistIds").strings().toSet(), result.getString("effectiveStylistId"), times("slots"), result.optString("reason").takeUnless { it.isBlank() || it == "null" }, result.optString("nextDate").takeUnless { it.isBlank() || it == "null" }, times("nextSlots"))
    }
    override suspend fun reserve(selection: Selection, requestId: String): Booking = booking(JSONObject(api.rpc("studioflow_android_book", JSONObject().put("p_slug", selection.slug).put("p_services", JSONArray(selection.serviceIds.toList())).put("p_date", selection.date).put("p_time", selection.slot!!.time).put("p_stylist", selection.slot.stylistId).put("p_name", selection.name).put("p_phone", selection.phone).put("p_instructions", selection.instructions).put("p_request", requestId))))
    override suspend fun bookings() = JSONArray(api.request("GET", "/rest/v1/studioflow_bookings", query = mapOf("select" to "id,owner_id,status,payload,hold_expires_at", "customer_id" to "eq.${api.session?.getJSONObject("user")?.getString("id") ?: error("Please sign in")}", "order" to "starts_at.desc"))).objects().map(::booking)
    override suspend fun reschedule(id: String, selection: Selection): Booking = booking(JSONObject(api.rpc("studioflow_android_reschedule", JSONObject().put("p_booking", id).put("p_date", selection.date).put("p_time", selection.slot!!.time).put("p_stylist", selection.slot.stylistId))))
    override suspend fun cancel(id: String) { api.rpc("studioflow_update_booking", JSONObject().put("p_id", id).put("p_status", "cancelled")) }
    private suspend fun paymentRequest(action: String, id: String, fields: JSONObject = JSONObject()) = JSONObject(api.request("POST", "/functions/v1/studioflow-payments", fields.put("action", action).put("bookingId", id)))
    private suspend fun paymentMode(id: String) = JSONObject(api.request("POST", "/functions/v1/nexora-mobile-qr", JSONObject().put("action", "mode").put("bookingId", id))).optString("mode")
    override suspend fun order(id: String): PaymentOrder { check(paymentMode(id) != "qr") { "A QR payment already exists. Open the QR or recheck payment status." }; val o = paymentRequest("create", id); return PaymentOrder(o.getString("keyId"), o.getString("orderId"), o.getLong("amount"), id) }
    override suspend fun verify(id: String, order: String, payment: String, signature: String) { val r = paymentRequest("verify", id, JSONObject().put("orderId", order).put("paymentId", payment).put("signature", signature)); if(r.optJSONObject("booking")?.optBoolean("refund_required") == true) error("Payment received after expiry; contact support for a refund.") }
    override suspend fun reconcile(id: String) { if(paymentMode(id) == "qr") { reconcileQr(id); return }; val r = paymentRequest("reconcile", id); if(r.optJSONObject("booking")?.optBoolean("refund_required") == true) error("Payment requires a refund. Contact support with your booking ID.") }
    override suspend fun qr(id: String): QrOrder { val o = JSONObject(api.request("POST", "/functions/v1/nexora-mobile-qr", JSONObject().put("action", "create").put("bookingId", id))); return QrOrder(o.getString("imageUrl"), o.getLong("amount"), o.getLong("expires")) }
    override suspend fun reconcileQr(id: String) { val r = JSONObject(api.request("POST", "/functions/v1/nexora-mobile-qr", JSONObject().put("action", "reconcile").put("bookingId", id))); if(r.optBoolean("refund_required")) error("Payment received after expiry. Contact support for a refund.") }
}
class LiveCustomer(private val api: SupabaseApi): CustomerRepository {
    private fun uid() = api.session?.getJSONObject("user")?.getString("id") ?: error("Please sign in")
    override suspend fun favorites() = JSONArray(api.request("GET", "/rest/v1/studioflow_android_favorites", query = mapOf("select" to "salon_slug", "customer_id" to "eq.${uid()}"))).objects().map { it.getString("salon_slug") }.toSet()
    override suspend fun favorite(slug: String, enabled: Boolean) { if(enabled) api.rpc("studioflow_android_favorite", JSONObject().put("p_slug", slug)) else api.request("DELETE", "/rest/v1/studioflow_android_favorites", query = mapOf("customer_id" to "eq.${uid()}", "salon_slug" to "eq.$slug")) }
    override suspend fun profile(): JSONObject {
        val profile = JSONObject(api.rpc("studioflow_android_profile"))
        val path = profile.optString("photo_path").takeIf { it.isNotBlank() && it != "null" }
        if(path != null) {
            // Photo retrieval must never prevent loading the customer's contact details.
            try {
            val signed = JSONObject(api.request("POST", "/storage/v1/object/sign/nexora-customer-private/$path", JSONObject().put("expiresIn", 300)))
            val relative = signed.optString("signedURL", signed.optString("signedUrl"))
            if(relative.startsWith("/object/sign/")) profile.put("photo_url", com.nexora.customer.BuildConfig.SUPABASE_URL + "/storage/v1" + relative)
            } catch(e: kotlinx.coroutines.CancellationException) { throw e } catch(_: Exception) { /* Photo can retry on refresh. */ }
        }
        return profile
    }
    override suspend fun updateProfile(name: String, phone: String, whatsapp: String, birthDate: String) { api.rpc("studioflow_customer_update_details", JSONObject().put("p_name", name).put("p_phone", phone).put("p_whatsapp", whatsapp).put("p_birth_date", birthDate)) }
    override suspend fun upload(bytes: ByteArray, mime: String, document: Boolean): String {
        require(bytes.size <= 5 * 1024 * 1024) { "Maximum upload size is 5 MB" }
        require(mime in if(document) listOf("application/pdf", "image/jpeg", "image/png") else listOf("image/jpeg", "image/png")) { "Choose a JPEG, PNG or permitted PDF document" }
        val extension = when(mime) { "application/pdf" -> "pdf"; "image/png" -> "png"; else -> "jpg" }
        val path = "${uid()}/${if(document) "documents" else "photos"}/${UUID.randomUUID()}.$extension"
        api.request("POST", "/storage/v1/object/nexora-customer-private/$path", bytes = bytes, mime = mime)
        api.rpc("studioflow_android_record_upload", JSONObject().put("p_path", path).put("p_document", document)); return path
    }
    override suspend fun rewards() = JSONArray(api.rpc("studioflow_android_rewards")).objects().map { Reward(it.optString("salon"), it.optInt("points"), it.optString("description")) }
    override suspend fun referral() = api.rpc("studioflow_android_referral").trim('"')
    override suspend fun applyReferral(code: String) { api.rpc("studioflow_android_apply_referral", JSONObject().put("p_code", code.trim().uppercase())) }
    override suspend fun registerToken(token: String) { api.rpc("studioflow_android_register_token", JSONObject().put("p_token", token)) }
    override suspend fun revokeToken(token: String) { api.request("DELETE", "/rest/v1/studioflow_android_devices", query = mapOf("customer_id" to "eq.${uid()}", "token" to "eq.$token")) }
}
