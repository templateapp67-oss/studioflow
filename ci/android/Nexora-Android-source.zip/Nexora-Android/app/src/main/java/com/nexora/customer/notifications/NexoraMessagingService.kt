package com.nexora.customer.notifications

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.nexora.customer.NexoraApplication
import com.nexora.customer.MainActivity
import com.nexora.customer.R
import kotlinx.coroutines.*

class NexoraMessagingService: FirebaseMessagingService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    override fun onNewToken(token: String) {
        val container = (application as NexoraApplication).container
        if(container.consent.pushes && container.auth.customer.value != null) scope.launch { runCatching { container.customer.registerToken(token) } }
    }
    override fun onMessageReceived(message: RemoteMessage) {
        val container = (application as NexoraApplication).container
        if(!container.consent.pushes || container.auth.customer.value?.id != message.data["customer_id"]) return
        val event = message.data["event_id"] ?: return
        val seen = getSharedPreferences("push_seen", MODE_PRIVATE)
        if(seen.getBoolean(event, false)) return
        seen.edit().putBoolean(event, true).apply()
        if(Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel("bookings", "Booking updates", NotificationManager.IMPORTANCE_DEFAULT))
        val pending = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        // Lock-screen text intentionally excludes names, services, medical information and payment data.
        manager.notify(message.messageId?.hashCode() ?: 1, NotificationCompat.Builder(this, "bookings").setSmallIcon(R.drawable.ic_nexora).setContentTitle("Nexora booking update").setContentText("Open Nexora to view your appointment update.").setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentIntent(pending).setAutoCancel(true).build())
    }
    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
