package com.nexora.customer.domain

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.*

data class Customer(val id: String, val email: String, val name: String)
data class Service(val id: String, val name: String, val category: String, val price: BigDecimal, val minutes: Int, val description: String, val image: String)
data class Specialist(val id: String, val name: String, val role: String, val avatar: String, val assigned: List<String>, val experienceYears: Int = 0, val bio: String = "", val work: List<StaffWork> = emptyList())
data class StaffWork(val image: String, val caption: String)
data class Promotion(val headline: String, val text: String, val image: String, val code: String)
data class PromoVideo(val title: String, val thumbnail: String, val source: String, val playable: String)
data class Salon(val ownerId: String, val slug: String, val name: String, val category: String, val city: String, val address: String, val about: String, val phone: String, val cover: String, val latitude: Double?, val longitude: Double?, val services: List<Service>, val staff: List<Specialist>, val gallery: List<String>, val promotion: Promotion?, val videos: List<PromoVideo>, val policies: String) {
    val startingPrice get() = services.minOfOrNull { it.price }
}
data class BookingAvailability(val specialistIds: Set<String>, val effectiveStylistId: String, val slots: List<Slot>, val reason: String?, val nextDate: String?, val nextSlots: List<Slot>)
data class Slot(val time: String, val label: String, val stylistId: String)
data class Booking(val id: String, val ownerId: String, val status: String, val name: String, val serviceId: String, val date: String, val time: String, val stylist: String, val total: BigDecimal, val paid: BigDecimal, val expires: String?, val refundRequired: Boolean = false, val serviceIds: Set<String> = emptySet())
data class Review(val name: String, val rating: Int, val comment: String, val verified: Boolean, val image: String = "")
data class Reward(val salon: String, val points: Int, val description: String)
data class PaymentOrder(val key: String, val orderId: String, val amount: Long, val bookingId: String)
data class QrOrder(val imageUrl: String, val amount: Long, val expires: Long)
data class Selection(val slug: String = "", val serviceIds: Set<String> = emptySet(), val stylistId: String = "any", val date: String = "", val slot: Slot? = null, val name: String = "", val phone: String = "", val instructions: String = "")
object Money {
    fun depositPaise(total: BigDecimal): Long { require(total.signum() >= 0); return total.multiply(BigDecimal(25)).setScale(0, RoundingMode.CEILING).longValueExact() }
    fun rupees(paise: Long) = BigDecimal.valueOf(paise, 2)
    fun display(amount: BigDecimal) = "₹" + amount.setScale(2, RoundingMode.HALF_UP).toPlainString()
}
fun distanceKm(aLat: Double, aLon: Double, bLat: Double, bLon: Double): Double {
    val lat = Math.toRadians(bLat - aLat); val lon = Math.toRadians(bLon - aLon)
    val a = sin(lat / 2).pow(2) + cos(Math.toRadians(aLat)) * cos(Math.toRadians(bLat)) * sin(lon / 2).pow(2)
    return 6371 * 2 * atan2(sqrt(a), sqrt(1 - a.coerceIn(0.0, 1.0)))
}

data class AvailabilityChoice(val selection: Selection, val slots: List<Slot>, val movedDate: Boolean)
fun chooseAvailability(selection: Selection, availability: BookingAvailability, autoNext: Boolean): AvailabilityChoice {
    val move = autoNext && availability.slots.isEmpty() && availability.nextDate != null && availability.nextSlots.isNotEmpty()
    return AvailabilityChoice(selection.copy(stylistId = availability.effectiveStylistId,
        date = if(move) availability.nextDate!! else selection.date, slot = null),
        if(move) availability.nextSlots else availability.slots, move)
}
