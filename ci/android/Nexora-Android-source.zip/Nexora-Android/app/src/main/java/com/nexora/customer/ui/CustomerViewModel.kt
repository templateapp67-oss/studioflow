package com.nexora.customer.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexora.customer.AppContainer
import com.nexora.customer.domain.*
import com.nexora.customer.data.detail
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.time.LocalDate
import java.time.ZoneId
import java.util.UUID

data class CustomerState(
    val salons: List<Salon> = emptyList(), val favorites: Set<String> = emptySet(), val bookings: List<Booking> = emptyList(),
    val customer: Customer? = null, val selection: Selection = Selection(date = LocalDate.now(ZoneId.of("Asia/Kolkata")).toString()),
    val availability: BookingAvailability? = null, val slotsLoading: Boolean = false, val slots: List<Slot> = emptyList(), val reviews: List<Review> = emptyList(), val rewards: List<Reward> = emptyList(),
    val referral: String = "", val profileLoaded: Boolean = false, val profile: JSONObject = JSONObject(), val busy: Boolean = false, val message: String? = null,
    val error: String? = null, val rescheduleId: String? = null, val activeBooking: Booking? = null, val payment: PaymentOrder? = null, val qr: QrOrder? = null
)
class CustomerViewModel(val container: AppContainer): ViewModel() {
    private val mutable = MutableStateFlow(CustomerState())
    val state = mutable.asStateFlow()
    private var slotJob: Job? = null
    private var requestId = UUID.randomUUID().toString()
    private var catalogJob: Job? = null
    init {
        refresh()
        viewModelScope.launch { container.auth.customer.collect { user ->
            slotJob?.cancel()
            mutable.update { if(it.customer == null && user != null) it.copy(customer = user, error = null) else CustomerState(salons = it.salons, customer = user) }
            if (user != null) account()
        } }
    }
    fun clearMessage() = mutable.update { it.copy(message = null, error = null) }
    private fun task(block: suspend () -> Unit) = viewModelScope.launch {
        mutable.update { it.copy(busy = true, error = null) }
        try { block() } catch(e: CancellationException) { throw e } catch(e: Exception) { mutable.update { it.copy(error = e.message ?: "Could not complete request") } }
        finally { mutable.update { it.copy(busy = false) } }
    }
    fun refresh() { catalogJob?.cancel(); catalogJob = task { val salons = container.salons.salons(); mutable.update { current ->
        val old = current.salons.find { it.slug == current.selection.slug }
        val fresh = salons.find { it.slug == current.selection.slug }
        val changed = current.activeBooking == null && old != null && (fresh == null || old.services != fresh.services || old.staff != fresh.staff)
        if(changed) current.copy(salons = salons, selection = current.selection.copy(serviceIds = current.selection.serviceIds.filter { id -> fresh?.services?.any { it.id == id } == true }.toSet(), slot = null), slots = emptyList(), availability = null, message = "The salon updated its menu or team. Review your services and check slots again.") else current.copy(salons = salons)
    } } }
    fun account() = task {
        val userId = state.value.customer?.id ?: return@task
        // Commit profile first: a bookings/rewards/photo failure must not erase account details.
        val profile = container.customer.profile()
        if(userId == state.value.customer?.id) mutable.update { current -> current.copy(profile = profile, profileLoaded = true, selection = current.selection.copy(
            name = current.selection.name.ifBlank { profile.detail("full_name").ifBlank { current.customer?.name.orEmpty() } },
            phone = current.selection.phone.ifBlank { profile.detail("phone").ifBlank { profile.detail("whatsapp_number") } })) }
        val bookings = container.bookings.bookings(); val favorites = container.customer.favorites()
        val rewards = container.customer.rewards(); val referral = container.customer.referral()
        if (userId == state.value.customer?.id) mutable.update { it.copy(bookings = bookings, favorites = favorites, rewards = rewards, referral = referral) }
    }
    fun signIn(email: String, password: String) = task { container.auth.signIn(email, password) }
    fun signUp(name: String, email: String, password: String, whatsapp: String, birthDate: String, referral: String) = task {
        require(name.trim().length >= 2) { "Enter your full name" }; require(password.length >= 8) { "Use at least 8 characters" }
        require(whatsapp.matches(Regex("^\\+91[1-9][0-9]{9}$"))) { "Enter a valid +91 WhatsApp number" }
        require(validBirthDate(birthDate)) { "Choose a valid date of birth (DD-MM-YYYY)" }
        val signed = container.auth.signUp(name, email, password, whatsapp, birthDate, referral.trim().uppercase())
        mutable.update { it.copy(message = if(signed) "Welcome to Nexora" else "Check your email to confirm your account, then sign in.") }
    }
    fun resetPassword(email: String) = task { require(email.contains('@')) { "Enter your email first" }; container.auth.resetPassword(email); mutable.update { it.copy(message = "If an account exists, a recovery email will be sent.") } }
    fun signOut() = task {
        val token = container.consent.cachedToken()
        try { if(token != null) container.customer.revokeToken(token) } finally {
            try { container.consent.stopPush() } finally { container.auth.signOut() }
        }
    }
    fun favorite(slug: String) = task { require(state.value.customer != null) { "Sign in to save salons" }; val enabled = slug !in state.value.favorites; container.customer.favorite(slug, enabled); mutable.update { it.copy(favorites = if(enabled) it.favorites + slug else it.favorites - slug) } }
    fun openSalon(slug: String) { slotJob?.cancel(); requestId = UUID.randomUUID().toString(); mutable.update { it.copy(selection = Selection(slug = slug, date = LocalDate.now(ZoneId.of("Asia/Kolkata")).toString(), name = it.profile.detail("full_name").ifBlank { it.customer?.name.orEmpty() }, phone = it.profile.detail("phone").ifBlank { it.profile.detail("whatsapp_number") }), slots = emptyList(), availability = null, reviews = emptyList(), activeBooking = null, rescheduleId = null, qr = null) }; task { val reviews = container.salons.reviews(slug); if(state.value.selection.slug == slug) mutable.update { it.copy(reviews = reviews) } } }
    fun editSelection(transform: (Selection) -> Selection) {
        slotJob?.cancel(); requestId = UUID.randomUUID().toString()
        mutable.update { it.copy(selection = transform(it.selection).copy(slot = null), slots = emptyList(), availability = null) }
    }
    fun contact(name: String, phone: String, instructions: String) { mutable.update { it.copy(selection = it.selection.copy(name = name, phone = phone, instructions = instructions)) } }
    fun chooseSlot(slot: Slot) { if(slot !in state.value.slots || state.value.slotsLoading) return; requestId = UUID.randomUUID().toString(); mutable.update { it.copy(selection = it.selection.copy(slot = slot)) } }
    fun loadSlots(autoNext: Boolean = false) {
        slotJob?.cancel()
        val selection = state.value.selection
        if(selection.serviceIds.isEmpty()) return
        mutable.update { it.copy(slotsLoading = true, slots = emptyList(), availability = null, selection = it.selection.copy(slot = null), error = null) }
        val request = state.value.selection
        slotJob = viewModelScope.launch {
            try {
                val result = container.bookings.availability(request)
                if(request != state.value.selection) return@launch
                val choice = chooseAvailability(request, result, autoNext)
                val move = choice.movedDate
                val updated = choice.selection
                val times = choice.slots
                mutable.update { it.copy(selection = updated, slots = times, availability = result.copy(slots = times, nextDate = if(move) null else result.nextDate), slotsLoading = false,
                    message = if(move) "No remaining times on ${request.date}. Showing next available date: ${updated.date}." else if(result.effectiveStylistId != request.stylistId) "Professional updated to match your selected services." else it.message) }
            } catch(e: CancellationException) { throw e }
            catch(e: Exception) { if(request == state.value.selection) mutable.update { it.copy(slotsLoading = false, error = e.message ?: "Could not check availability. Retry.") } }
        }
    }
    fun nextAvailableDate() { val date = state.value.availability?.nextDate ?: return; editSelection { it.copy(date = date) }; loadSlots() }
    fun reserve(onReady: () -> Unit) = task {
        val selection = state.value.selection
        require(state.value.customer != null) { "Sign in before booking" }
        require(selection.slot != null) { "Choose an available slot" }
        require(selection.name.trim().length >= 2 && selection.phone.filter(Char::isDigit).length in 10..15) { "Enter your name and valid phone number" }
        val moving = state.value.rescheduleId
        val booking = try { if(moving != null) container.bookings.reschedule(moving, selection) else container.bookings.reserve(selection, requestId) }
        catch(e: Exception) {
            if(e is CancellationException) throw e
            if(e.message.orEmpty().contains("Slot unavailable", true) || e.message.orEmpty().contains("choose another time", true)) {
                editSelection { it }; loadSlots()
                mutable.update { it.copy(message = "That time was just taken. Choose a freshly checked slot.") }
            }
            throw e
        }
        mutable.update { it.copy(activeBooking = booking, qr = null, message = if(moving != null) "Appointment rescheduled. Your payment is preserved." else "Slot reserved. Complete the 25% advance to confirm.") }; onReady(); account()
    }
    fun startReschedule(booking: Booking) {
        val salon = state.value.salons.find { it.ownerId == booking.ownerId } ?: return
        openSalon(salon.slug)
        mutable.update { it.copy(rescheduleId = booking.id, selection = it.selection.copy(serviceIds = booking.serviceIds.ifEmpty { setOf(booking.serviceId) })) }
    }
    fun openPayment(booking: Booking) { mutable.update { it.copy(activeBooking = booking, qr = null, payment = null) } }
    fun preparePayment(open: (PaymentOrder) -> Unit) = task { val id = state.value.activeBooking?.id ?: error("Choose a booking"); val order = container.bookings.order(id); mutable.update { it.copy(payment = order) }; open(order) }
    fun paymentFailed() { account(); mutable.update { it.copy(error = "Payment did not complete. Recheck payment status before trying again.") } }
    fun verify(orderId: String, paymentId: String, signature: String) = task { val id = state.value.payment?.bookingId ?: error("Recheck payment from My Bookings"); container.bookings.verify(id, orderId, paymentId, signature); mutable.update { it.copy(message = "Payment verified. Booking confirmed.") }; account() }
    fun reconcile(qr: Boolean = false) = task { val id = state.value.activeBooking?.id ?: error("Choose a booking"); if(qr) container.bookings.reconcileQr(id) else container.bookings.reconcile(id); mutable.update { it.copy(message = "Payment verified. Refreshing your booking.") }; account() }
    fun qr() = task { val id = state.value.activeBooking?.id ?: error("Choose a booking"); val qr = container.bookings.qr(id); mutable.update { it.copy(qr = qr) } }
    fun cancel(id: String) = task { container.bookings.cancel(id); account() }
    fun review(slug: String, rating: Int, comment: String) = task { container.salons.review(slug, state.value.profile.detail("full_name").ifBlank { state.value.customer?.name.orEmpty() }, rating, comment); val reviews = container.salons.reviews(slug); mutable.update { it.copy(reviews = reviews, message = "Your review has been saved") } }
    fun profile(name: String, phone: String, whatsapp: String, birthDate: String) = task { require(name.trim().length >= 2) { "Enter your full name" }; require(whatsapp.matches(Regex("^\\+91[1-9][0-9]{9}$"))) { "Enter a valid +91 WhatsApp number" }; require(validBirthDate(birthDate)) { "Choose a valid date of birth (DD-MM-YYYY)" }; container.customer.updateProfile(name.trim(), phone.trim().ifBlank { whatsapp }, whatsapp, birthDate); mutable.update { it.copy(message = "Profile saved") }; account() }
    fun upload(bytes: ByteArray, mime: String, document: Boolean) = task { container.customer.upload(bytes, mime, document); mutable.update { it.copy(message = "Private upload saved") }; account() }
    fun referral(code: String) = task { container.customer.applyReferral(code); mutable.update { it.copy(message = "Referral linked") } }
    fun enablePush() = task { require(state.value.customer != null) { "Sign in before enabling notifications" }; val token = container.consent.startPush(); container.customer.registerToken(token); mutable.update { it.copy(message = "Booking notifications enabled") } }
    fun disablePush() = task { container.consent.cachedToken()?.let { container.customer.revokeToken(it) }; container.consent.stopPush() }
    companion object { fun factory(container: AppContainer) = object: ViewModelProvider.Factory { @Suppress("UNCHECKED_CAST") override fun <T: ViewModel> create(modelClass: Class<T>): T = CustomerViewModel(container) as T } }
}
