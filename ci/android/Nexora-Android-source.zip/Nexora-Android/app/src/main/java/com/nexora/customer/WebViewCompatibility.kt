package com.nexora.customer

/** Tailwind 4's shared customer UI requires Chromium 111 or newer.
 * Reject unsupported providers before any WebView instance/native engine is created.
 */
internal fun supportsCustomerWebUi(versionName: String?): Boolean =
    versionName?.substringBefore('.')?.toIntOrNull()?.let { it >= 111 } == true
