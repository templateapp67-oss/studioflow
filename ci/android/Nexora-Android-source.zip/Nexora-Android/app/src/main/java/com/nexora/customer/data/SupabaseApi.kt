package com.nexora.customer.data

import com.nexora.customer.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiException(val status: Int, message: String): IOException(message)
class SupabaseApi(private val store: SecureSessionStore) {
    private val http = OkHttpClient.Builder().callTimeout(30, TimeUnit.SECONDS).build()
    private val refreshLock = Mutex()
    private val currentSession = MutableStateFlow(store.read()?.let { runCatching { JSONObject(it) }.getOrNull() })
    val sessionFlow = currentSession.asStateFlow()
    val session: JSONObject? get() = currentSession.value
    fun saveSession(value: JSONObject?) { store.write(value?.toString()); currentSession.value = value }
    private suspend fun token(): String? = refreshLock.withLock {
        val current = session ?: return@withLock null
        if (current.optLong("expires_at") > System.currentTimeMillis() / 1000 + 60) return@withLock current.optString("access_token")
        try {
            val response = request("POST", "/auth/v1/token", JSONObject().put("refresh_token", current.getString("refresh_token")), mapOf("grant_type" to "refresh_token"), false)
            if(session !== current) return@withLock session?.optString("access_token")
            saveSession(JSONObject(response).apply { put("expires_at", System.currentTimeMillis() / 1000 + optLong("expires_in", 3600)) })
        } catch (e: ApiException) { if (e.status == 400 || e.status == 401) saveSession(null); throw e }
        session?.getString("access_token")
    }
    suspend fun request(method: String, path: String, body: JSONObject? = null, query: Map<String, String> = emptyMap(), authenticated: Boolean = true, bytes: ByteArray? = null, mime: String = "application/json"): String {
        val access = if (authenticated) token() else null
        return withContext(Dispatchers.IO) {
            val url = (BuildConfig.SUPABASE_URL.trimEnd('/') + path).toHttpUrl().newBuilder().apply { query.forEach { (key, value) -> addQueryParameter(key, value) } }.build()
            val content = bytes?.toRequestBody(mime.toMediaType()) ?: body?.toString()?.toRequestBody("application/json".toMediaType())
            val builder = Request.Builder().url(url).header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY).header("Prefer", "return=representation")
            access?.let { builder.header("Authorization", "Bearer $it") }
            builder.method(method, if (method == "GET" || method == "DELETE") null else content ?: "{}".toRequestBody("application/json".toMediaType()))
            http.newCall(builder.build()).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val json = runCatching { JSONObject(text) }.getOrNull()
                    throw ApiException(response.code, json?.optString("msg")?.takeIf { it.isNotBlank() } ?: json?.optString("error_description")?.takeIf { it.isNotBlank() } ?: json?.optString("message")?.takeIf { it.isNotBlank() } ?: json?.optString("error")?.takeIf { it.isNotBlank() } ?: "Request failed (${response.code}). Try again.")
                }
                text
            }
        }
    }
    suspend fun rpc(name: String, body: JSONObject = JSONObject()) = request("POST", "/rest/v1/rpc/$name", body)
}
