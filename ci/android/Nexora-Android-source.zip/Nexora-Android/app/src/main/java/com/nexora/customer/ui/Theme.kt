package com.nexora.customer.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val palette = lightColorScheme(primary = Color(0xFF5841E8), onPrimary = Color.White, primaryContainer = Color(0xFFECE7FF), secondary = Color(0xFF75658E), background = Color(0xFFF9F8FF), surface = Color.White, surfaceVariant = Color(0xFFF0EDF8), outlineVariant = Color(0xFFE3DFEF))
@Composable fun NexoraTheme(content: @Composable () -> Unit) { MaterialTheme(colorScheme = palette, content = content) }
