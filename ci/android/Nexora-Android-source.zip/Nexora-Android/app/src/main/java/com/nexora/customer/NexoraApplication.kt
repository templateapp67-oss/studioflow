package com.nexora.customer

import android.app.Application
import com.nexora.customer.data.*
import com.nexora.customer.notifications.ConsentManager

class NexoraApplication: Application() {
    val container: AppContainer by lazy { AppContainer(this) }
    override fun onCreate() { super.onCreate(); if(BuildConfig.FIREBASE_ENABLED) com.nexora.customer.notifications.ConsentManager(this).applySavedConsent() }
}
class AppContainer(application: Application) {
    val api = SupabaseApi(SecureSessionStore(application))
    val auth: AuthRepository = LiveAuth(api)
    val salons: SalonRepository = LiveSalons(api)
    val bookings: BookingRepository = LiveBookings(api)
    val customer: CustomerRepository = LiveCustomer(api)
    val consent = ConsentManager(application)
}
