package com.nexora.customer.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.nexora.customer.BuildConfig
import com.nexora.customer.domain.*

fun openLink(context: Context, url: String) {
    val uri = Uri.parse(url)
    if(uri.scheme in listOf("https", "geo", "tel")) runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
}
fun share(context: Context, text: String) { context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "Share Nexora")) }
@Composable fun DiscoveryScreen(s: CustomerState, vm: CustomerViewModel, favoritesOnly: Boolean, openSalon: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("All") }
    var nearby by rememberSaveable { mutableStateOf(false) }
    var location by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var locationMessage by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    fun locate() {
        if(context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            val manager = context.getSystemService(LocationManager::class.java)
            val value = manager.getProviders(true).mapNotNull { runCatching { manager.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
            location = value?.let { it.latitude to it.longitude }; nearby = value != null
            locationMessage = if(value == null) "Location is unavailable. Search your city or area below." else "Sorted by distance from your approximate location."
        }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if(it) locate() else locationMessage = "Search by city or area to find nearby salons." }
    val categories = listOf("All") + s.salons.flatMap { it.services.map(Service::category) }.distinct().sorted()
    val filtered = s.salons.filter { salon ->
        (!favoritesOnly || salon.slug in s.favorites) && (query.isBlank() || listOf(salon.name, salon.city, salon.address, salon.category).plus(salon.services.map { it.name }).any { it.contains(query, true) }) && (category == "All" || salon.services.any { it.category == category })
    }.let { list -> if(nearby && location != null) list.sortedBy { salon -> if(salon.latitude != null && salon.longitude != null) distanceKm(location!!.first, location!!.second, salon.latitude, salon.longitude) else Double.MAX_VALUE } else list }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { PageTitle(if(favoritesOnly) "Your favorites" else "Hello, ${s.customer?.name?.substringBefore(' ')?.takeIf { it.isNotBlank() } ?: "Guest"}", if(favoritesOnly) "Your next good hair day, saved." else "Find a little time for yourself.") }
        item { OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("Salon, service, city or area") }, leadingIcon = { Icon(Icons.Outlined.Search, null) }, singleLine = true, shape = RoundedCornerShape(18.dp)) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = { permission.launch(Manifest.permission.ACCESS_COARSE_LOCATION) }) { Icon(Icons.Outlined.LocationOn, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Nearby") }; OutlinedButton(onClick = { vm.refresh() }, enabled = !s.busy) { Text("Refresh") } }; locationMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) } }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(categories) { item -> FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item) }) } } }
        if(!favoritesOnly) {
            val offers = filtered.filter { it.promotion != null }
            if(offers.isNotEmpty()) {
                item { Text("A little extra, for you", style = MaterialTheme.typography.titleLarge) }
                item { LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(offers, key = { it.slug }) { salon ->
                    ElevatedCard(onClick = { openSalon(salon.slug) }, modifier = Modifier.width(290.dp), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        if(salon.promotion!!.image.isNotBlank()) AsyncImage(salon.promotion.image, null, Modifier.fillMaxWidth().height(115.dp), contentScale = ContentScale.Crop)
                        Column(Modifier.padding(16.dp)) { Text(salon.promotion.headline.ifBlank { "Salon offer" }, style = MaterialTheme.typography.titleMedium); Text(salon.promotion.text); Text(salon.name, style = MaterialTheme.typography.labelSmall) }
                    }
                } } }
            }
            val pastOwners = s.bookings.filter { it.status == "completed" }.map { it.ownerId }.toSet()
            val preferredCategories = s.salons.filter { it.ownerId in pastOwners }.flatMap { it.services.map(Service::category) }.toSet()
            val recommended = filtered.sortedByDescending { salon -> (if(salon.slug in s.favorites) 5 else 0) + (if(salon.ownerId in pastOwners) 3 else 0) + salon.services.count { it.category in preferredCategories } }.take(5)
            if(recommended.isNotEmpty()) {
                item { Text("Recommended for you", style = MaterialTheme.typography.titleLarge); Text(if(pastOwners.isEmpty()) "Explore published salons and services." else "Based on your completed visits and saved salons.", style = MaterialTheme.typography.bodySmall) }
                item { LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(recommended, key = { it.slug }) { salon -> OutlinedCard(onClick = { openSalon(salon.slug) }, modifier = Modifier.width(230.dp)) { Column(Modifier.padding(16.dp)) { Text(salon.name, style = MaterialTheme.typography.titleMedium); Text(salon.city); Text(salon.startingPrice?.let { "From ${Money.display(it)}" } ?: "Explore services", color = MaterialTheme.colorScheme.primary) } } } } }
            }
            item { Text(if(nearby) "Salons near you" else "Explore salons", style = MaterialTheme.typography.titleLarge); Text("Published services, current availability.", style = MaterialTheme.typography.bodySmall) }
        }
        if(filtered.isEmpty()) item { EmptyState(if(favoritesOnly) "Save a salon using the heart icon to find it here." else if(s.busy) "Finding salons…" else "No published salons match. Try another city or service.") }
        items(filtered, key = { it.slug }) { salon ->
            ElevatedCard(onClick = { openSalon(salon.slug) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                if(salon.cover.isNotBlank()) AsyncImage(salon.cover, "${salon.name} salon", Modifier.fillMaxWidth().height(175.dp), contentScale = ContentScale.Crop)
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row { Column(Modifier.weight(1f)) { Text(salon.name, style = MaterialTheme.typography.titleLarge); Text("${salon.city} · ${salon.category.replace('-', ' ')}", style = MaterialTheme.typography.bodySmall) }; IconButton(onClick = { vm.favorite(salon.slug) }, enabled = !s.busy) { Icon(if(salon.slug in s.favorites) Icons.Outlined.Favorite else Icons.Outlined.FavoriteBorder, "Save ${salon.name}", tint = MaterialTheme.colorScheme.primary) } }
                    if(nearby && location != null && salon.latitude != null && salon.longitude != null) Text("%.1f km away".format(distanceKm(location!!.first, location!!.second, salon.latitude, salon.longitude)))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(salon.startingPrice?.let { "From ${Money.display(it)}" } ?: "View services", color = MaterialTheme.colorScheme.primary); Text("Explore →", style = MaterialTheme.typography.labelLarge) }
                }
            }
        }
    }
}
