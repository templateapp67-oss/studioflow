package com.nexora.customer.domain

import org.junit.Assert.*
import org.junit.Test

class AvailabilityTest {
    private val next = Slot("10:00", "10:00 AM", "eligible")
    private val selection = Selection(slug="salon", serviceIds=setOf("manicure"), stylistId="old", date="2026-10-18", slot=Slot("09:00","09:00 AM","old"))
    private val result = BookingAvailability(setOf("eligible"), "any", emptyList(), "no_times_on_date", "2026-10-19", listOf(next))
    @Test fun closedDefaultDateMovesToActualOpening() {
        val choice = chooseAvailability(selection, result, true)
        assertEquals("2026-10-19", choice.selection.date)
        assertEquals(listOf(next), choice.slots)
        assertTrue(choice.movedDate)
        assertNull(choice.selection.slot)
    }
    @Test fun explicitDateRemainsSelectedWithNextDateSuggestion() {
        val choice = chooseAvailability(selection, result, false)
        assertEquals(selection.date, choice.selection.date)
        assertTrue(choice.slots.isEmpty())
        assertFalse(choice.movedDate)
    }
    @Test fun changedServiceCannotKeepUnassignedProfessionalOrOldSlot() {
        val choice = chooseAvailability(selection, result.copy(slots=listOf(next)), true)
        assertEquals("any", choice.selection.stylistId)
        assertNull(choice.selection.slot)
        assertEquals(selection.serviceIds, choice.selection.serviceIds)
        assertEquals(selection.date, choice.selection.date)
    }
    @Test fun noAssignedStaffNeverInventsSlots() {
        val choice = chooseAvailability(selection, result.copy(specialistIds=emptySet(),nextDate=null,nextSlots=emptyList(),reason="no_eligible_specialist"),true)
        assertTrue(choice.slots.isEmpty())
        assertFalse(choice.movedDate)
    }
    @Test fun emptyNextDateResponseCannotMoveAppointment() {
        assertFalse(chooseAvailability(selection,result.copy(nextSlots=emptyList()),true).movedDate)
    }
}
