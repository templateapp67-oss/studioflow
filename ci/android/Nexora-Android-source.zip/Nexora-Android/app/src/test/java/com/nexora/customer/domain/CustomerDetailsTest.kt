package com.nexora.customer.domain

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class CustomerDetailsTest {
    @Test fun dobIsDayMonthYearIncludingLeadingZeros() {
        assertEquals("09-02-2000", displayBirthDate("2000-02-09"))
        assertEquals("29-02-2000", displayBirthDate("2000-02-29"))
    }
    @Test fun missingAndInvalidDobNeverRenderNull() {
        for(value in listOf("", "null", "NULL", "2001-02-29", "09-02-2000")) assertEquals("", displayBirthDate(value))
    }
    @Test fun dobRejectsFutureAndImpossibleDates() {
        val today = LocalDate.of(2026,10,18)
        for(value in listOf("2026-10-19", "1899-12-31", "2001-02-29", "null", "")) assertFalse(validBirthDate(value,today))
        assertTrue(validBirthDate("1900-01-01",today)); assertTrue(validBirthDate(today.toString(),today)); assertTrue(validBirthDate("2000-02-29",today))
    }
    @Test fun missingContactDetailsAreBlank() {
        assertEquals("",cleanDetail(null)); assertEquals("",cleanDetail(" null ")); assertEquals("",cleanDetail("NULL"))
        assertEquals("+919876543210",cleanDetail(" +919876543210 ")); assertEquals("Anu",cleanDetail(" Anu "))
    }
}
