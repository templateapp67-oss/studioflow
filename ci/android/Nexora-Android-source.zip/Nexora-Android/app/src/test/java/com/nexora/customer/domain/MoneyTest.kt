package com.nexora.customer.domain
import org.junit.Assert.*
import org.junit.Test
import java.math.BigDecimal
class MoneyTest {
    @Test fun depositUsesPaiseAndRoundsUp() {
        assertEquals(25000L, Money.depositPaise(BigDecimal("1000")))
        assertEquals(6225L, Money.depositPaise(BigDecimal("249")))
        assertEquals(6226L, Money.depositPaise(BigDecimal("249.01")))
        assertEquals(1L, Money.depositPaise(BigDecimal("0.01")))
    }
    @Test fun balanceNeverLosesAPaise() {
        val total=BigDecimal("259.99");val advance=Money.rupees(Money.depositPaise(total))
        assertEquals(BigDecimal("65.00"), advance)
        assertEquals(BigDecimal("194.99"), total-advance)
    }
    @Test(expected=IllegalArgumentException::class) fun negativePricesAreRejected() { Money.depositPaise(BigDecimal("-1")) }
    @Test fun distanceIsSymmetricAndZeroAtSamePoint() {
        assertEquals(0.0,distanceKm(12.9,77.6,12.9,77.6),0.0001)
        assertEquals(distanceKm(12.9,77.6,13.1,77.8),distanceKm(13.1,77.8,12.9,77.6),0.0001)
    }
}
