package com.nexora.customer

import org.junit.Assert.*
import org.junit.Test

class WebViewCompatibilityTest {
    @Test fun rejectsUnsupportedProvidersBeforeLoadingTheEngine() {
        for (version in listOf(null, "", "unknown", "83.0.4103.120", "110.0.5481.154")) {
            assertFalse("Unsupported provider: $version", supportsCustomerWebUi(version))
        }
        for (version in listOf("111.0.5563.58", "124.0.6367.4", "150.0.1.2")) {
            assertTrue("Supported provider: $version", supportsCustomerWebUi(version))
        }
    }
}
