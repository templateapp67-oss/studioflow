package com.nexora.customer

import android.util.Base64
import android.webkit.*
import java.io.ByteArrayInputStream
import androidx.test.platform.app.InstrumentationRegistry
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URI
import java.security.KeyStore
import java.security.cert.CertificateFactory
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

/** Optional instrumentation-only transport for the managed host's HTTPS proxy.
 * Production APK contains neither this adapter nor its test CA. Hostname verification stays enabled.
 * Every response comes from the real selected Supabase project; no fixture JSON is substituted.
 */
object TestNetworkTransport {
    private val executor=Executors.newFixedThreadPool(4)
    fun install(view:WebView):Boolean {
        val args=InstrumentationRegistry.getArguments()
        val port=args.getString("qaProxyPort")?.toIntOrNull() ?: return false
        val context=InstrumentationRegistry.getInstrumentation().context
        val certificate=context.assets.open("test-proxy-ca.pem").use { CertificateFactory.getInstance("X.509").generateCertificate(it) }
        val store=KeyStore.getInstance(KeyStore.getDefaultType()).apply { load(null);setCertificateEntry("test-host",certificate) }
        val factory=TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()).apply { init(store) }
        val manager=factory.trustManagers.filterIsInstance<X509TrustManager>().single()
        val ssl=SSLContext.getInstance("TLS").apply { init(null,arrayOf(manager),null) }
        val client=OkHttpClient.Builder().sslSocketFactory(ssl.socketFactory,manager).proxy(Proxy(Proxy.Type.HTTP,InetSocketAddress("10.0.2.2",port))).callTimeout(25,TimeUnit.SECONDS).build()
        val origin="https://appassets.androidplatform.net"
        WebViewCompat.addWebMessageListener(view,"NexoraTestHttp",setOf(origin)) { _,message,source,main,reply ->
            if(!main||source.toString()!=origin)return@addWebMessageListener
            val input=JSONObject(message.data.orEmpty());val id=input.getString("id")
            executor.execute {
                val result=JSONObject().put("id",id)
                try {
                    val url=input.getString("url");val uri=URI(url)
                    require(uri.scheme=="https"&&uri.host=="zilwgiuiygqqardzutxi.supabase.co")
                    val method=input.getString("method");val header=input.getJSONObject("headers")
                    val builder=Request.Builder().url(url).header("Origin",origin)
                    header.keys().forEach { key -> if(key.lowercase() !in setOf("host","content-length","connection"))builder.header(key,header.getString(key)) }
                    val bytes=Base64.decode(input.optString("body"),Base64.DEFAULT)
                    builder.method(method,if(method in listOf("GET","HEAD"))null else bytes.toRequestBody(header.optString("content-type").toMediaTypeOrNull()))
                    client.newCall(builder.build()).execute().use { response ->
                        val headers=JSONObject();for(name in response.headers.names())headers.put(name,response.header(name))
                        result.put("ok",true).put("status",response.code).put("headers",headers).put("body",Base64.encodeToString(response.body?.bytes() ?: byteArrayOf(),Base64.NO_WRAP))
                    }
                } catch(e:Exception) { result.put("ok",false).put("error",e.javaClass.simpleName+": "+e.message) }
                // A previous Activity may have closed while its HTTP call was running.
                // Never deliver into a detached/destroyed Chromium instance.
                val payload=result.toString()
                view.post { if(view.isAttachedToWindow)runCatching { reply.postMessage(payload) } }
            }
        }
        val script="""
            (()=>{if(window.top!==window)return;const original=window.fetch.bind(window),pending=new Map();let n=0;
            NexoraTestHttp.onmessage=event=>{const r=JSON.parse(event.data),p=pending.get(r.id);if(!p)return;pending.delete(r.id);if(!r.ok){p.reject(new Error(r.error));return;}const bytes=Uint8Array.from(atob(r.body),x=>x.charCodeAt(0));p.resolve(new Response([204,205,304].includes(r.status)?null:bytes,{status:r.status,headers:r.headers}));};
            window.fetch=async(input,init)=>{const request=new Request(input,init);if(new URL(request.url).host!=='zilwgiuiygqqardzutxi.supabase.co')return original(input,init);const bytes=new Uint8Array(await request.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=4096)binary+=String.fromCharCode(...bytes.subarray(i,i+4096));return new Promise((resolve,reject)=>{const id=String(++n);pending.set(id,{resolve,reject});if(request.signal.aborted){pending.delete(id);reject(new DOMException('Aborted','AbortError'));return;}request.signal.addEventListener('abort',()=>{pending.delete(id);reject(new DOMException('Aborted','AbortError'))},{once:true});NexoraTestHttp.postMessage(JSON.stringify({id,url:request.url,method:request.method,headers:Object.fromEntries(request.headers.entries()),body:btoa(binary)}));});};})();
        """.trimIndent()
        if(WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT))WebViewCompat.addDocumentStartJavaScript(view,script,setOf(origin))
        else {
            val delegate=view.webViewClient
            view.webViewClient=object:WebViewClient() {
                override fun shouldInterceptRequest(v:WebView,r:WebResourceRequest):WebResourceResponse? {
                    val response=delegate.shouldInterceptRequest(v,r) ?: return null
                    if(!r.isForMainFrame||r.url.host!="appassets.androidplatform.net"||response.mimeType!="text/html")return response
                    val html=response.data.bufferedReader().use { it.readText() }.replace("<head>","<head><script>"+script+"</script>")
                    return WebResourceResponse("text/html","UTF-8",ByteArrayInputStream(html.toByteArray()))
                }
                override fun shouldOverrideUrlLoading(v:WebView,r:WebResourceRequest)=delegate.shouldOverrideUrlLoading(v,r)
                override fun onPageFinished(v:WebView,url:String)=delegate.onPageFinished(v,url)
                override fun onReceivedError(v:WebView,r:WebResourceRequest,e:WebResourceError)=delegate.onReceivedError(v,r,e)
                override fun onRenderProcessGone(v:WebView,d:RenderProcessGoneDetail)=delegate.onRenderProcessGone(v,d)
            }
        }
        return true
    }
}
