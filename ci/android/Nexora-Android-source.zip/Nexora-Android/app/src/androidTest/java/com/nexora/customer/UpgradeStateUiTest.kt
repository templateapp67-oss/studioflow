package com.nexora.customer

import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class UpgradeStateUiTest {
    @Test fun seedPersistentState() {
        val h=CustomerUiTest()
        ActivityScenario.launch(MainActivity::class.java).use { s ->
            h.until(s,"Home missing before update","!!document.querySelector('.cr-app nav')")
            h.js(s,"localStorage.setItem('nexora_qa_upgrade_marker','preserved-v5-to-v6')")
            assertEquals("\"preserved-v5-to-v6\"",h.js(s,"localStorage.getItem('nexora_qa_upgrade_marker')"))
        }
    }
    @Test fun updatedPackageRetainsState() {
        val h=CustomerUiTest()
        ActivityScenario.launch(MainActivity::class.java).use { s ->
            h.until(s,"Home missing after update","!!document.querySelector('.cr-app nav')")
            assertEquals("\"preserved-v5-to-v6\"",h.js(s,"localStorage.getItem('nexora_qa_upgrade_marker')"))
            h.screenshot("updated-home")
        }
    }
}
